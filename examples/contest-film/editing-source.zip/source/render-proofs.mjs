import { mkdir } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";
import { bundle } from "@remotion/bundler";
import {
  openBrowser,
  renderStill,
  selectComposition,
} from "@remotion/renderer";
const output = path.resolve(process.argv[2] || "build/proofs");
const frames = process.argv.slice(3).map(Number);
if (!frames.length)
  throw Error("Supply one or more frame numbers after the output directory.");
await mkdir(output, { recursive: true });
const localChrome =
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const browserExecutable =
  process.env.CHROME_BIN || (existsSync(localChrome) ? localChrome : undefined);
const serveUrl = await bundle({ entryPoint: path.resolve("src/index.tsx") });
const browser = await openBrowser("chrome", { browserExecutable });
try {
  const base = {
    serveUrl,
    browserExecutable,
    puppeteerInstance: browser,
    inputProps: {},
  };
  const composition = await selectComposition({ ...base, id: "Strateg" });
  for (const frame of frames) {
    await renderStill({
      ...base,
      composition,
      frame,
      imageFormat: "png",
      output: path.join(output, frame + ".png"),
    });
  }
} finally {
  await browser.close({ silent: true });
}
