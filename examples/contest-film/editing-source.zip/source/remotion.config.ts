import { existsSync } from "node:fs";
import { Config } from "@remotion/cli/config";

const systemChrome =
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const browser =
  process.env.CHROME_BIN ||
  (existsSync(systemChrome) ? systemChrome : undefined);
if (browser) Config.setBrowserExecutable(browser);
Config.setVideoImageFormat("jpeg");
Config.setJpegQuality(95);
Config.setConcurrency(6);
