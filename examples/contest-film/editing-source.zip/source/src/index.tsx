import React from "react";
import { AbsoluteFill, Composition, Sequence, registerRoot } from "remotion";
import { starts, total, Shell } from "./kit";
import { scenes } from "./Scenes";
import "./style.css";
import "./fonts";
const light = new Set([1, 3, 5, 7, 9, 11]);
export function Film() {
  return (
    <AbsoluteFill>
      {scenes.map((Scene, i) => (
        <Sequence
          key={i}
          from={starts[i]}
          durationInFrames={(starts[i + 1] ?? total) - starts[i]}
        >
          <Shell n={i} light={light.has(i)}>
            <Scene />
          </Shell>
        </Sequence>
      ))}
    </AbsoluteFill>
  );
}
function Root() {
  return (
    <Composition
      id="Strateg"
      component={Film}
      width={1920}
      height={1080}
      fps={30}
      durationInFrames={total}
    />
  );
}
registerRoot(Root);
