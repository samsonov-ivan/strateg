# -*- coding: utf-8 -*-
"""Restore the partner's PDF and canonical source snapshot via the repository CLI."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

demo = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("brief", type=Path, help="Official PDF supplied in the competition cabinet")
parser.add_argument("--repo", type=Path, default=Path.cwd(), help="Unpacked repository containing strateg/")
args = parser.parse_args()
repo = args.repo.resolve()
project = demo / "projects" / "family-data"
source = next(r for r in map(json.loads, (project / "state/sources.jsonl").read_text(encoding="utf-8").splitlines()) if r["id"] == "S-001")
raw = args.brief.read_bytes()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def run(data_root, *parts):
    cmd = [sys.executable, "-m", "strateg", *parts, "--json"]
    reply = subprocess.run(cmd, cwd=repo, env={**os.environ, "STRATEG_ROOT": str(data_root)}, stdout=subprocess.PIPE, check=True)
    result = json.loads(reply.stdout)
    if not result["ok"]:
        raise SystemExit(result)
    return result["data"]

if sha(raw) != source["file_sha256"]:
    raise SystemExit("The PDF differs from S-001. Download the original Example Brief from the competition cabinet.")
with TemporaryDirectory() as scratch_name:
    scratch = Path(scratch_name)
    run(scratch, "project", "new", "restore", "--title", "Restore S-001")
    result = run(scratch, "source", "add", "--project", "restore", "--file", str(args.brief.resolve()))
    fresh = scratch / "projects" / "restore" / "materials" / "snapshots" / (result["id"] + ".md")
    body = fresh.read_text(encoding="utf-8").split("\n\n", 1)[1].encode("utf-8")
if sha(body) != source["sha256"]:
    raise SystemExit("Source text differs from S-001. Check repository version and requirements.txt.")
header = f"<!-- источник: {source['file']} | получен: {source['retrieved_at']} | sha256: {source['sha256']} -->\n\n".encode("utf-8")
restored = [(project / source["file"], raw), (project / source["snapshot"], header + body)]
for path, data in restored:
    if path.exists() and path.read_bytes() != data:
        raise SystemExit("An existing file differs. Extract a fresh demo copy first: " + str(path))
for path, data in restored:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_bytes(data)
q = run(demo, "verify", "quotes", "--project", "family-data")
s = run(demo, "strategy", "check", "--project", "family-data")
v = run(demo, "validate", "--project", "family-data")
print(f"Verified quotes {q['verified']}/{q['checked']}; checked equations {s['valid_equations']}; validation errors {v['errors']}, warnings {v['warnings']}.")
