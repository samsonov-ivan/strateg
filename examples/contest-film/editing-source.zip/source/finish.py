"""Make a chaptered MP4, readable Russian subtitles and a matching chapter index."""

import json
import math
import re
import subprocess
import argparse
import textwrap
from pathlib import Path

HERE = Path(__file__).resolve().parent


def stamp(t, sep=","):
    ms = round(t * 1000)
    return f"{ms // 3600000:02}:{ms // 60000 % 60:02}:{ms // 1000 % 60:02}{sep}{ms % 1000:03}"


def subtitles(timing):
    entries = []
    for phrase in timing["phrases"]:
        punct = re.findall(
            r"[А-Яа-яЁёA-Za-z0-9]+[^А-Яа-яЁёA-Za-z0-9\s]*(?:\s+[—–](?=\s))?",
            phrase["caption"],
        )
        words = phrase["words"]
        if len(punct) != len(words):
            raise ValueError(phrase["caption"])
        # Wrap medium-length, punctuated cues to two lines of at most 39 chars.
        first = 0
        while first < len(words):
            last = first + 1
            while last < len(words):
                next_text = " ".join(punct[first : last + 1])
                if (
                    len(textwrap.wrap(next_text, 39)) > 2
                    or words[last]["end"] - words[first]["start"] > 4.7
                ):
                    break
                last += 1
                if punct[last - 1].endswith((".", "!", "?")):
                    break
            caption = "\n".join(textwrap.wrap(" ".join(punct[first:last]), 39))
            start = words[first]["start"] if first else phrase["start"]
            end = (
                phrase["end"]
                if last == len(words)
                else min(words[last]["start"] - 0.01, words[last - 1]["end"] + 0.1)
            )
            entries.append((start, end, caption))
            first = last
    return (
        "\n\n".join(
            f"{n}\n{stamp(s)} --> {stamp(e)}\n{c}"
            for n, (s, e, c) in enumerate(entries, 1)
        )
        + "\n"
    )


def ff(args):
    subprocess.run(
        ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *map(str, args)],
        check=True,
    )



def main():
    parser = argparse.ArgumentParser(description="Add the final stereo track, chapters and subtitles to the Remotion picture.")
    parser.add_argument("video", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    timing = json.loads((HERE / "timing.json").read_text())
    story = json.loads((HERE / "story.json").read_text())
    fps = 30
    frames = math.ceil(timing["duration"] * fps)
    starts = [math.ceil(v * fps) / fps for v in timing["scene_starts"]]
    boundaries = starts + [frames / fps]
    chapters = [";FFMETADATA1", "title=Стратег — от брифа до пересмотра решения"]
    for i, scene in enumerate(story):
        chapters += ["[CHAPTER]", "TIMEBASE=1/1000", f"START={round(1000 * starts[i])}",
                     f"END={round(1000 * boundaries[i + 1])}", "title=" + scene["chapter"]]
    import tempfile
    with tempfile.TemporaryDirectory() as temp:
        meta = Path(temp) / "chapters.ffmeta"
        meta.write_text("\n".join(chapters) + "\n")
        ff(["-i", args.video, "-i", HERE / "master.m4a", "-i", meta,
            "-map", "0:v:0", "-map", "1:a:0", "-map_chapters", "2", "-map_metadata", "2",
            "-metadata:s:a:0", "language=rus", "-c", "copy", "-movflags", "+faststart",
            args.out / "strateg-final.mp4"])
    (args.out / "strateg-final.ru.srt").write_text(subtitles(timing))
    lines = [f"- {int(t)//60:02d}:{int(t)%60:02d}　{scene['chapter']}"
             for t, scene in zip(starts, story)]
    (args.out / "chapters.md").write_text("# Главы конкурсного ролика\n\n" + "\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
