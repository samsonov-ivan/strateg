import {
  cancelRender,
  continueRender,
  delayRender,
  staticFile,
} from "remotion";
if (typeof document !== "undefined" && typeof FontFace !== "undefined") {
  const id = delayRender("Loading the local fonts");
  const assets = [
    ["Strategy Sans", "DejaVuSans", "100 550"],
    ["Strategy Sans", "DejaVuSans-Bold", "551 900"],
    ["Strategy Mono", "DejaVuSansMono", "100 900"],
  ];
  Promise.all(
    assets.map(async ([family, file, weight]) => {
      const face = new FontFace(
        family,
        `url("${staticFile("fonts/" + file + ".ttf")}")`,
        { weight },
      );
      await face.load();
      document.fonts.add(face);
    }),
  )
    .then(() => continueRender(id))
    .catch(cancelRender);
}
