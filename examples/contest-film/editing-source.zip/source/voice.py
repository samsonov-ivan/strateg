"""Synthesize the script with Piper Denis, keeping its measured word boundaries."""

import hashlib
import json
import re
import sys
import wave
from pathlib import Path

import numpy as np
from piper import PiperVoice, SynthesisConfig

HERE = Path(__file__).resolve().parent


def main(model, work):
    story = json.loads((HERE / "story.json").read_text())
    work.mkdir(parents=True, exist_ok=True)
    cache = work / "takes"
    cache.mkdir(exist_ok=True)
    voice = PiperVoice.load(model, include_alignments=True)
    config = SynthesisConfig(length_scale=1.13, noise_scale=0.48, noise_w_scale=0.33)
    rate = voice.config.sample_rate

    def synthesize(phrase):
        key = hashlib.sha256(phrase.encode()).hexdigest()
        data, marks = cache / (key + ".npy"), cache / (key + ".json")
        if data.is_file() and marks.is_file():
            return np.load(data), json.loads(marks.read_text())
        chunks = list(voice.synthesize(phrase, config, include_alignments=True))
        sound = np.concatenate([chunk.audio_float_array for chunk in chunks])
        bounds = []
        offset, first, last = 0, None, None
        for chunk in chunks:
            if not chunk.phoneme_alignments:
                raise RuntimeError("Install piper-tts[alignment]")
            for phoneme in chunk.phoneme_alignments:
                symbol = phoneme.phoneme
                if symbol.isspace() or symbol in ("^", "$"):
                    if first is not None:
                        bounds.append((first, last))
                    first = last = None
                elif symbol not in ",;:.!?—-":
                    if first is None:
                        first = offset
                    last = offset + int(phoneme.num_samples)
                offset += int(phoneme.num_samples)
        if first is not None:
            bounds.append((first, last))
        words = re.findall(r"[А-Яа-яЁёA-Za-z0-9]+", phrase)
        if len(words) != len(bounds):
            # eSpeak can elide spaces in clitics. The containing word boundary
            # remains measured by synthesizing the two halves independently.
            if len(words) < 2:
                raise ValueError((phrase, bounds))
            pos = [m.start() for m in re.finditer(r"\s+", phrase)]
            if not pos:
                raise ValueError((phrase, bounds))
            cut = min(pos, key=lambda i: abs(i - len(phrase) / 2))
            left, left_marks = synthesize(phrase[:cut].strip())
            right, right_marks = synthesize(phrase[cut:].strip())
            pad = np.zeros(round(rate * 0.032), dtype=np.float32)
            shift = len(left) + len(pad)
            sound = np.concatenate([left, pad, right])
            aligned = left_marks + [
                [w, lo + shift, hi + shift] for w, lo, hi in right_marks
            ]
        else:
            nonzero = np.flatnonzero(np.abs(sound) > 0.008)
            trim = max(0, int(nonzero[0]) - int(rate * 0.042))
            sound = sound[
                trim : min(len(sound), int(nonzero[-1]) + int(rate * 0.071))
            ].copy()
            fade = min(int(rate * 0.007), len(sound) // 2)
            sound[:fade] *= np.linspace(0, 1, fade)
            sound[-fade:] *= np.linspace(1, 0, fade)
            aligned = [
                [w, max(0, lo - trim), min(len(sound), hi - trim)]
                for w, (lo, hi) in zip(words, bounds)
            ]
        np.save(data, sound)
        marks.write_text(json.dumps(aligned, ensure_ascii=False))
        return sound, aligned

    pieces, scenes, phrases = [], [], []
    cursor = 0

    def push(signal):
        nonlocal cursor
        pieces.append(signal)
        cursor += len(signal)

    def pause(seconds):
        push(np.zeros(round(rate * seconds), dtype=np.float32))

    pause(0.22)
    for sid, scene in enumerate(story):
        scenes.append(0 if sid == 0 else cursor / rate - 0.22)
        for beat, phrase in enumerate(scene["speech"]):
            take, marks = synthesize(phrase)
            start = cursor
            push(take)
            phrases.append(
                {
                    "scene": sid,
                    "beat": beat,
                    "start": round(start / rate, 3),
                    "end": round(cursor / rate, 3),
                    "caption": phrase,
                    "words": [
                        {
                            "text": w,
                            "start": round((start + lo) / rate, 3),
                            "end": round((start + hi) / rate, 3),
                        }
                        for w, lo, hi in marks
                    ],
                }
            )
            default_pause = 0.54 if beat == len(scene["speech"]) - 1 else 0.18
            pause(scene.get("beat_pauses", {}).get(str(beat), default_pause))
        print(scene["id"], round(cursor / rate, 1), flush=True)
    pause(0.45)
    with wave.open(str(work / "voice.wav"), "wb") as out:
        out.setparams((1, 2, rate, 0, "NONE", "not compressed"))
        for piece in pieces:
            out.writeframes(
                np.clip(piece * 32767, -32767, 32767).astype("<i2").tobytes()
            )
    (work / "timing.json").write_text(
        json.dumps(
            {"duration": cursor / rate, "scene_starts": scenes, "phrases": phrases},
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main(*map(Path, sys.argv[1:3]))
