"""Render original 1080 × 1920 artwork against speech-derived timings."""

import argparse
import bisect
import json
import math
import os
import subprocess
from concurrent.futures import ProcessPoolExecutor
from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
ART = HERE / "evidence"
STORY = json.loads((HERE / "story.json").read_text())
W, H, FPS = 1080, 1920, 30
DARK = "#0e1f22"
DARK2 = "#193437"
BLACK = "#10272a"
PAPER = "#f0eee1"
INK = "#183234"
MINT = "#8cecc9"
GOLD = "#ecfc57"
FADE = "#abc0b3"
LINE = "#45615b"
SOFT = "#dce2ce"
DIM = "#455c50"
PALE = "#f8f8ed"
RED = "#ffb59f"
LIGHT = {"prompt", "problem", "product", "money", "blind", "change"}


def clamp(v):
    return max(0, min(1, v))


def ease(v):
    return 1 - (1 - clamp(v)) ** 3


def blend(a, b, p):
    return a + (b - a) * p


@lru_cache(maxsize=320)
def font(size, style):
    names = {
        "reg": "DejaVuSans",
        "bold": "DejaVuSans-Bold",
        "heavy": "DejaVuSansCondensed-Bold",
        "mono": "DejaVuSansMono",
    }
    loc = Path(os.environ.get("STRATEG_FONTS", "/usr/share/fonts/truetype/dejavu"))
    return ImageFont.truetype(str(loc / (names[style] + ".ttf")), int(size))


@lru_cache(maxsize=3800)
def sprite(text, size, color, style):
    ft = font(size, style)
    left, top, right, bottom = ft.getbbox(text, anchor="lt")
    if right <= left or bottom <= top:
        return Image.new("RGBA", (1, 1))
    layer = Image.new("RGBA", (right - left + 3, bottom - top + 4))
    ImageDraw.Draw(layer).text(
        (-left + 1, -top + 1), text, font=ft, fill=color, anchor="lt"
    )
    return layer


def text(im, x, y, s, size, color, style="reg", maxw=None):
    if maxw:
        while size > 14 and font(size, style).getlength(s) > maxw:
            size -= 1
    label = sprite(s, size, color, style)
    im.paste(label, (round(x), round(y)), label)
    return label.width


def box(d, x, y, w, h, color, r=24, outline=None, width=2):
    d.rounded_rectangle(
        (int(x), int(y), int(x + w), int(y + h)),
        radius=r,
        fill=color,
        outline=outline,
        width=width,
    )


def line(d, x, y, xx, yy, c, width=3):
    d.line((int(x), int(y), int(xx), int(yy)), fill=c, width=width)


def wrap(s, size, style, w):
    lines = []
    for word in s.split():
        if lines and font(size, style).getlength(lines[-1] + " " + word) <= w:
            lines[-1] += " " + word
        else:
            lines.append(word)
    return lines


def para(im, x, y, s, size, col, style="reg", width=770, spacing=15):
    for row in wrap(s, size, style, width):
        text(im, x, y, row, size, col, style)
        y += size + spacing
    return y


def top(im, d, scene, local, part):
    bright = scene["id"] in LIGHT
    fg, mut, rule = (INK, DIM, "#a8b9a8") if bright else (PAPER, FADE, LINE)
    for i in range(3):
        line(d, 80 + i * 16, 125, 95 + i * 16, 96 + i * 2, INK if bright else GOLD, 7)
    text(im, 149, 91, "Стратег", 42, fg, "bold")
    text(im, 626, 103, "MGIMO × AI CHALLENGE", 23, mut, "mono", 365)
    line(d, 78, 171, 999, 171, rule, 2)
    x = 76 + round(30 * (1 - ease(local / 0.5)))
    for i, word in enumerate(scene["title"]):
        text(im, x, 236 + i * 86, word, 80, fg, "heavy", 925)
    line(d, 78, 1703, 998, 1703, rule, 2)
    text(im, 79, 1730, scene["source"], 23, mut, "mono", 926)
    line(d, 79, 1800, 997, 1800, rule, 3)
    line(d, 79, 1800, 79 + max(2, 918 * part), 1800, INK if bright else MINT, 5)


def label(im, x, y, s, light=False):
    text(im, x, y, s, 24, DIM if light else FADE, "mono", 870)


def tag(im, d, x, y, s, fill, color):
    w = round(font(23, "bold").getlength(s)) + 44
    box(d, x, y, w, 49, fill, 24)
    text(im, x + 22, y + 13, s, 23, color, "bold")


def large(im, x, y, s, col, w=920, size=134):
    return text(im, x, y, s, size, col, "heavy", w)


@lru_cache(maxsize=9)
def asset(name):
    return Image.open(ART / name).convert("RGB")


def picture(im, name, x, y, w, h, src=None):
    raw = asset(name)
    if src:
        raw = raw.crop(tuple(map(int, src)))
    if raw.size != (w, h):
        raw = raw.resize((w, h), Image.Resampling.BILINEAR)
    im.paste(raw, (round(x), round(y)))


def gap(im, d, b, p, u):
    label(im, 80, 524, "ВАЛОВАЯ ПРИБЫЛЬ ЗА ГОД")
    box(d, 79, 603, 910, 302, DARK2, 34)
    text(im, 110, 640, "Без изменений", 29, FADE, "mono")
    large(im, 107, 717, "279", PAPER, 320, 133)
    text(im, 419, 785, "млн ₽", 40, FADE, "bold")
    text(im, 635, 640, "Цель", 29, FADE, "mono")
    large(im, 630, 717, "285", GOLD, 310, 133)
    travel = clamp(u / 3.6)
    line(d, 108, 962, 955, 962, LINE, 5)
    line(d, 108, 962, 108 + 847 * ease(travel), 962, MINT, 5)
    dot = 108 + 847 * ease(travel)
    d.ellipse((dot - 10, 952, dot + 10, 972), fill=MINT)
    val = ["6 млн ₽", "1 бриф", "4 варианта", "1 пересмотр"][b]
    large(im, 79, 1055, val, GOLD, 900, 125)
    text(
        im,
        83,
        1210,
        [
            "разрыв между прогнозом и целью",
            "оператора с семейным тарифом",
            "на выбор руководителю",
            "в новом сеансе со своим журналом",
        ][b],
        38,
        PAPER,
        "reg",
        900,
    )


def prompt(im, d, b, p, u):
    box(d, 83, 490, 909, 785, "#d9dece", 27)
    box(d, 76, 477, 908, 788, "#faf9f0", 27, "#bac6b3")
    text(im, 111, 520, "Запрос.txt", 40, INK, "bold")
    text(im, 110, 597, "Исходное сообщение", 28, DIM, "mono")
    lines = [
        ("Подготовь по приложенному брифу", 0),
        ("законченную стратегию для", 1),
        ("руководителя цифрового продукта.", 1),
        ("Отдай её одним самостоятельным", 1),
        ("документом на русском языке,", 1),
        ("чтобы руководитель мог принять", 1),
        ("решение; цифры и допущения", 3),
        ("должны быть проверяемыми.", 3),
    ]
    if b == 2:
        lines = [
            ("Используй только бриф и явно", 2),
            ("обозначенные собственные", 2),
            ("предположения. Для проверки", 2),
            ("вычислений можно пользоваться", 2),
            ("Python.", 2),
        ]
    for i, (s, beat) in enumerate(lines):
        y = 686 + 58 * i
        if beat == b:
            box(
                d,
                106,
                y - 9,
                min(841, round(font(39, "reg").getlength(s)) + 24),
                54,
                "#d6efbb",
                8,
            )
        text(im, 117, y, s, 39, INK, "reg", 828)
    tag(im, d, 109, 1186, "PDF / 11 страниц", SOFT, INK)
    tag(im, d, 420, 1186, "Запрос / 1 документ", SOFT, INK)


def evidence(im, d, b, p, u):
    rows = [
        ("S-001  /  БРИФ", "279 млн ₽", "Прогноз без изменений"),
        ("S-001  /  БРИФ", "285 млн ₽", "Целевая валовая прибыль"),
        ("СТРАТЕГИЯ, § 2  /  ДОПУЩЕНИЕ", "40 в неделю", "Уникальные подходящие семьи"),
    ]
    active = min(b, 2)
    for i, (k, val, note) in enumerate(rows):
        yy = 498 + i * 244
        selected = i == active
        dx = round(12 * (1 - ease(p / 0.55))) if selected else 0
        x = 80 + dx
        box(
            d,
            x,
            yy,
            908,
            211,
            MINT if selected and i < 2 else GOLD if selected else DARK2,
            27,
        )
        fore, mut = (INK, DIM) if selected else (PAPER, FADE)
        text(im, x + 31, yy + 26, k, 24, mut, "mono")
        text(im, x + 28, yy + 82, val, 72, fore, "heavy", 560)
        text(im, x + 32, yy + 166, note, 27, fore)
    if b == 3:
        text(im, 83, 1260, "Проверим поток во втором сеансе →", 35, GOLD, "bold", 904)


def problem(im, d, b, p, u):
    for i, (title, sub, action) in enumerate(
        [
            ("Семейный тариф", "Кончается доля интернета", "Можно выдать из пакета"),
            ("Собственный роутер", "Не проходит оплата", "Можно пополнить баланс"),
        ]
    ):
        yy = 503 + i * 205
        box(d, 80, yy, 910, 171, INK if i == 0 else SOFT, 24)
        color, subc = (PAPER, MINT) if i == 0 else (INK, DIM)
        text(im, 110, yy + 28, title, 47, color, "heavy")
        text(im, 111, yy + 107, sub if b < 2 else action, 33, subc)
    label(im, 82, 968, "УСЛОВНЫЙ ЭПИЗОД НА ОДНОМ ТАРИФЕ", True)
    text(im, 82, 1032, "100 МБ", 79, INK, "heavy")
    text(im, 613, 1032, "1 ГБ", 79, INK, "heavy")
    text(im, 86, 1140, "у участника", 30, DIM)
    text(im, 616, 1140, "в общем пакете", 30, DIM)
    z = ease(u / 2)
    line(d, 358, 1075, 358 + 194 * z, 1075, INK, 6)
    if z > 0.6:
        d.polygon(((545, 1059), (565, 1075), (545, 1091)), fill=INK)
    if b >= 2:
        tag(im, d, 80, 1221, "Права + согласие", INK, MINT)


def options(im, d, b, p, u):
    choices = [
        ("O-001", "Обычный кабинет"),
        ("O-002", "Предупреждение со ссылкой"),
        ("O-003", "Выдача из карточки"),
        ("O-004", "Закрыть разработку"),
    ]
    active = (0, 1, 2, 1)[b]
    for i, (code, title) in enumerate(choices):
        y = 504 + i * 173
        selected = i == active
        x = 79 + (11 * (1 - ease(p / 0.38)) if selected else 0)
        box(d, x, y, 907, 139, GOLD if selected else DARK2, 25)
        text(im, x + 30, y + 25, code, 24, INK if selected else FADE, "mono")
        text(im, x + 28, y + 71, title, 45, INK if selected else PAPER, "bold", 833)
    text(
        im,
        83,
        1240,
        "Сравним с обычным обслуживанием"
        if b == 3
        else "Цена и обратимость различаются",
        33,
        MINT,
        "reg",
        900,
    )


def phone(im, d, b, p, u):
    drift = round(math.sin(u * 0.35) * 4)
    y = 496 + drift
    box(d, 205, y, 670, 765, INK, 62)
    box(d, 221, y + 17, 638, 729, "#e9ecdc", 48)
    box(d, 460, y + 31, 160, 22, INK, 11)
    text(
        im,
        265,
        y + 84,
        ["Экран блокировки", "Семейный тариф", "Права доступа", "Состояние данных"][b],
        45,
        INK,
        "heavy",
        554,
    )
    text(
        im,
        267,
        y + 155,
        [
            "Сообщение организатору",
            "После входа",
            "Участник меняет настройку",
            "Проверка перед отправкой",
        ][b],
        24,
        DIM,
        "mono",
        548,
    )
    box(d, 253, y + 221, 572, 294, "#ffffff", 28)
    text(
        im,
        279,
        y + 248,
        ["Уведомление", "Доля участника", "Доступ к остатку", "Проверка журнала"][b],
        31,
        DIM,
        "reg",
        520,
    )
    if b == 0:
        para(
            im,
            280,
            y + 334,
            "У вас новое сообщение в приложении.",
            45,
            INK,
            "bold",
            507,
            9,
        )
    elif b == 1:
        text(im, 275, y + 321, "100 МБ", 68, INK, "heavy")
        text(im, 278, y + 422, "В пакете семьи есть 1 ГБ", 29, DIM, "reg", 523)
    elif b == 2:
        pos = blend(708, 665, ease(p / 0.7))
        box(d, 651, y + 320, 115, 66, "#8f9a8b" if p > 0.3 else "#299f7a", 33)
        d.ellipse((pos, y + 329, pos + 48, y + 377), fill=PALE)
        text(im, 277, y + 343, "Отозван", 45, INK, "bold")
    else:
        para(im, 278, y + 318, "Статус расчётов устарел", 45, INK, "bold", 490, 12)
    box(d, 253, y + 554, 572, 104, INK, 24)
    text(
        im,
        280,
        y + 588,
        [
            "Открыть приложение",
            "Перейти к выдаче",
            "Очередь закрыта",
            "Отправка остановлена",
        ][b],
        37,
        MINT,
        "bold",
        515,
    )
    label(im, 207, 1310, "Иллюстрация интерфейса", True)


def trial(im, d, b, p, u):
    text(im, 80, 501, "Исходный план", 36, FADE, "mono")
    large(im, 77, 577, "40 × 6 = 240", GOLD, 918, 114)
    text(im, 82, 733, "уникальных семей за шесть недель", 35, PAPER)
    for index, (name, col) in enumerate(
        [("Предупреждение", MINT), ("Обычный кабинет", GOLD)]
    ):
        x = 80 + index * 467
        y = 851
        box(d, x, y, 442, 310, DARK2, 27)
        text(im, x + 25, y + 25, name, 29, PAPER, "bold", 397)
        text(im, x + 23, y + 87, "120", 77, col, "heavy")
        for j in range(12):
            xx = x + 31 + (j % 6) * 49
            yy = y + 206 + j // 6 * 37
            d.ellipse(
                (xx, yy, xx + 18, yy + 18),
                fill=col if u > min(2.1, (j + index * 3) * 0.11) else LINE,
            )
    text(
        im,
        81,
        1217,
        [
            "Случайное назначение целой семьи",
            "Распределение 1 : 1 до контакта",
            "Исход в журнале через 7 суток",
            "Знаменатель — все назначенные семьи",
        ][b],
        35,
        MINT,
        "bold",
        914,
    )


def money(im, d, b, p, u):
    vals = ["18", "+6 596 ₽", "−723 ₽", "до 90 000 ₽"]
    labels = [
        "предотвращённых перебоев",
        "добавочная валовая прибыль за год",
        "слабый сценарий за год",
        "запрос на исследование в I квартале",
    ]
    box(d, 79, 520, 917, 348, INK, 30)
    text(
        im,
        111,
        559,
        [
            "Основной сценарий",
            "Основной сценарий",
            "Слабый сценарий",
            "Предложение руководителю",
        ][b],
        31,
        MINT,
        "mono",
    )
    large(im, 108 + 12 * (1 - ease(p / 0.5)), 645, vals[b], GOLD, 847, 117)
    text(im, 114, 804, labels[b], 31, PAPER, "reg", 839)
    if b < 3:
        label(im, 81, 957, "ДОПОЛНИТЕЛЬНАЯ ВАЛОВАЯ ПРИБЫЛЬ", True)
        line(d, 79, 1113, 979, 1113, "#afc0ad", 3)
        deltas = [0, -960, 420, 1314, 1261, 1211, 1163, 1116, 1071]
        for i, v in enumerate(deltas):
            x = 94 + i * 100
            part = ease((u - i * 0.08) / 0.7)
            h = abs(v) / 1314 * 84 * part
            d.rectangle(
                (x, 1113 - h if v > 0 else 1113, x + 57, 1113 if v > 0 else 1113 + h),
                fill=INK if v >= 0 else "#ad654e",
            )
        text(im, 82, 1227, "Вклад по месяцам, основной сценарий", 27, DIM, "mono", 910)
    else:
        text(im, 84, 958, "II квартал", 34, DIM, "mono")
        large(im, 81, 1034, "до 482 160 ₽", INK, 900, 93)
        text(im, 83, 1179, "Полевой пилот требует согласования", 32, DIM, "reg", 910)


def cli(im, d, b, p, u):
    labels = [
        "Стратегия.pdf  /  стр. 1 из 8",
        "Вывод команды  /  verify quotes",
        "Вывод команды  /  strategy check",
        "Исходное решение  /  учебная копия",
    ]
    label(im, 81, 502, labels[b])
    if b == 0:
        box(d, 76, 566, 921, 688, PAPER, 19)
        # Show the exact PDF page; pan from the title to the first decision.
        y = 53 + round(37 * ease(p / 3.8))
        picture(im, "strategy-page.png", 90, 579, 893, 661, (43, y, 1138, y + 810))
    elif b in (1, 2):
        img = "quotes.png" if b == 1 else "check.png"
        picture(im, img, 80, 571, 910, 607)
        text(
            im, 82, 1231, "Источник и расчёт проверяются отдельно", 30, MINT, "reg", 900
        )
    else:
        for i, (key, st) in enumerate(
            [
                ("D-001", "Подготовить условный календарь"),
                ("K-001", "Аналитику · 31 марта 2027"),
                ("G1–G4", "Согласования открыты"),
            ]
        ):
            y = 589 + 200 * i
            box(d, 79, y, 910, 169, DARK2, 23)
            text(im, 108, y + 22, key, 25, FADE, "mono")
            text(im, 108, y + 80, st, 44, MINT if i == 0 else PAPER, "bold", 848)


def blind(im, d, b, p, u):
    label(im, 81, 517, "ОДИН БРИФ  /  ТРИ ОБЕЗЛИЧЕННЫЕ ЗАПИСКИ", True)
    for i, (mark, winning) in enumerate([("1", True), ("2", True), ("3", False)]):
        x = 81 + i * 309
        y = 619 + round((1 - ease((u - i * 0.12) / 0.7)) * 36)
        selected = (b == 1 and winning) or (b == 2 and not winning)
        box(d, x, y, 286, 363, INK if selected else SOFT, 25)
        fg = PAPER if selected else INK
        text(
            im,
            x + 24,
            y + 29,
            "Рецензент " + mark,
            24,
            MINT if selected else DIM,
            "mono",
            248,
        )
        text(im, x + 20, y + 105, "01", 88, GOLD if selected else INK, "heavy")
        text(im, x + 23, y + 223, "место", 27, fg)
        text(
            im,
            x + 22,
            y + 293,
            "Стратег" if winning else "Прежний чат",
            31,
            fg,
            "bold",
            246,
        )
    text(
        im,
        80,
        1078,
        [
            "Авторы были скрыты",
            "2 из 3 выбрали «Стратега»",
            "Третий выбрал прежний чат",
        ][b],
        52,
        INK,
        "heavy",
        917,
    )
    para(
        im,
        83,
        1181,
        [
            "У каждого рецензента свой порядок A, B, C.",
            "Медиана из десяти баллов: 10 у агента, 9 у свежего чата.",
            "С прежним сильным ответом преимущество по правилу теста не установлено.",
        ][b],
        29,
        DIM,
        "reg",
        900,
        10,
    )


def chat(im, d, b, p, u):
    box(d, 77, 502, 918, 795, DARK2, 33)
    text(im, 112, 544, "Выдержка из нового чата", 38, PAPER, "bold", 839)
    line(d, 111, 619, 954, 619, LINE, 2)
    if b < 2:
        label(im, 112, 675, "РУКОВОДИТЕЛЬ  /  УЧЕБНАЯ ПОПРАВКА")
        box(d, 110, 741, 849, 341, "#deebd5", 24)
        para(
            im,
            142,
            788,
            "«До результата оставляем тот же тариф, шесть недель на набор и семь суток наблюдения после последнего включения».",
            43,
            INK,
            "reg",
            773,
            15,
        )
        text(im, 115, 1162, "96 разных семей · 8 недель журнала", 29, MINT, "mono", 836)
    else:
        label(im, 112, 675, "СТРАТЕГ  /  ОТВЕТ НОВОГО СЕАНСА")
        q = json.loads((ART / "chat.json").read_text())["quote"]
        para(im, 114, 784, "«" + q + "»", 45, PAPER, "bold", 806, 20)
        text(im, 116, 1180, "Сохранённый проект family-data", 28, MINT, "mono", 830)


def change(im, d, b, p, u):
    b = min(b, 3)
    label(im, 81, 520, "УЧЕБНЫЙ ЖУРНАЛ  /  ВПЕРВЫЕ ПОДОШЕДШИЕ СЕМЬИ", True)
    values = [10, 13, 11, 14, 12, 10, 15, 11]
    for i, v in enumerate(values):
        x = 96 + i * 111
        h = v * 10 * ease((u - i * 0.09) / 0.7)
        box(d, x, 865 - h, 68, max(2, h), INK if i % 2 == 0 else "#577465", 8)
        text(im, x + 7, 893, str(v), 29, DIM, "mono")
    line(d, 82, 864, 984, 864, "#92a48f", 2)
    vals = ["12 × 6 = 72", "36 + 36", "20 недель", "72 < 212"]
    labels = [
        "назначения в учебном окне",
        "по группам, вместо 120 + 120",
        "для 240 назначений + 7 суток исхода",
        "до минимального плана не хватает 140 семей",
    ]
    large(im, 80, 1009, vals[b], INK, 913, 104)
    text(im, 84, 1177, labels[b], 35, DIM, "bold", 900)
    if b == 3:
        tag(im, d, 82, 1255, "Решение требует пересмотра", INK, MINT)


def decision(im, d, b, p, u):
    rows = [
        ("D-001 → D-002", "Оставить обычный кабинет"),
        ("K-001 → K-002", "Аналитику · 31 марта 2027"),
        ("УСЛОВИЕ ВОЗВРАТА", "≥ 212 семей за 6 недель"),
        ("G1–G4", "Ожидают согласования"),
    ]
    for i, (name, value) in enumerate(rows):
        y = 494 + i * 175
        on = i == b
        box(d, 79, y, 908, 145, (GOLD if i != 2 else MINT) if on else DARK2, 23)
        text(im, 106, y + 21, name, 23, INK if on else FADE, "mono")
        text(im, 105, y + 71, value, 46, INK if on else PAPER, "heavy", 853)
    text(
        im, 80, 1250, "Данные → основание → решение → поручение", 31, MINT, "mono", 918
    )


PAINT = {
    "gap": gap,
    "prompt": prompt,
    "evidence": evidence,
    "problem": problem,
    "options": options,
    "product": phone,
    "trial": trial,
    "money": money,
    "cli": cli,
    "blind": blind,
    "chat": chat,
    "change": change,
    "decision": decision,
}


@lru_cache(maxsize=2500)
def caption_chunks(phrase_text, word_count):
    # Small, stable groups keep each word inside the phone-safe caption area.
    words = [
        t.strip(".,!?—;:«»")
        for t in phrase_text.replace(" — ", " ").split()
        if t.strip(".,!?—;:«»")
    ]
    if len(words) != word_count:
        raise ValueError(phrase_text)
    chunks = []
    start = 0
    while start < len(words):
        end = start + 1
        while (
            end < len(words)
            and end - start < 4
            and font(47, "bold").getlength(" ".join(words[start : end + 1])) < 825
        ):
            end += 1
        if len(words) - end == 1 and end - start > 2:
            end -= 1
        chunks.append((start, end))
        start = end
    return chunks


def captions(im, d, phrase, t, light):
    words = phrase["words"]
    idx = max(0, bisect.bisect_right([w["start"] for w in words], t) - 1)
    lower, upper = next(
        (a, b) for a, b in caption_chunks(phrase["caption"], len(words)) if a <= idx < b
    )
    fg = INK if light else PAPER
    line(d, 81, 1439, 143, 1439, INK if light else MINT, 4)
    text(im, 81, 1474, "Диктор", 23, DIM if light else FADE, "mono")
    x = 82
    y = 1545
    for j in range(lower, upper):
        w = words[j]["text"]
        width = font(47, "bold").getlength(w)
        if j == idx:
            box(d, x - 6, y - 15, width + 17, 76, INK if light else GOLD, 12)
        text(im, x, y, w, 47, (PAPER if light else INK) if j == idx else fg, "bold")
        x += width + 24
    # Hold the last word just through the inter-phrase breath.


def camera(im, scene, beat, elapsed):
    # Keep captions and masthead locked while the work surface changes scale.
    # The camera settles into a new angle on the first accented word of each beat.
    left, top, right, bottom = 0, 454, 1080, 1388
    region = im.crop((left, top, right, bottom))
    zoom = 0.018 * ease(elapsed / 1.05) + 0.012 * clamp(elapsed / 7)
    cx = 0.50 + (-1 if beat % 2 else 1) * 0.12
    width = region.width / (1 + zoom)
    height = region.height / (1 + zoom)
    dx = (region.width - width) * cx
    dy = (region.height - height) * (0.37 if scene % 2 else 0.63)
    viewport = region.resize(
        region.size, Image.Resampling.BILINEAR, box=(dx, dy, dx + width, dy + height)
    )
    im.paste(viewport, (left, top))


def frame(t, scene_index, timeline):
    scene = STORY[scene_index]
    phrases = [p for p in timeline["phrases"] if p["scene"] == scene_index]
    beat = max(0, bisect.bisect_right([p["start"] - 0.08 for p in phrases], t) - 1)
    phrase = phrases[beat]
    local = t - timeline["scene_starts"][scene_index]
    light = scene["id"] in LIGHT
    im = Image.new("RGB", (W, H), PAPER if light else DARK)
    d = ImageDraw.Draw(im)
    top(im, d, scene, local, t / timeline["duration"])
    PAINT[scene["id"]](im, d, beat, max(0, t - phrase["start"]), local)
    camera(im, scene_index, beat, max(0, t - phrase["start"]))
    # The colored incoming edge gives major cuts direction. It clears the
    # work surface in eight frames, and never crosses the spoken captions.
    if scene_index and 0 <= local < 0.27:
        w = round((1 - ease(local / 0.27)) * W)
        if w > 0:
            d.rectangle((0, 454, w, 1388), fill=INK if light else GOLD)
    captions(im, d, phrase, t, light)
    return im


def section(info):
    work, timeline, idx, first, last = info
    path = Path(work) / f"part-{idx:02d}.mp4"
    cmd = [
        "ffmpeg",
        "-v",
        "error",
        "-y",
        "-f",
        "rawvideo",
        "-pix_fmt",
        "rgb24",
        "-s",
        f"{W}x{H}",
        "-r",
        str(FPS),
        "-i",
        "-",
        "-an",
        "-c:v",
        "libx264",
        "-threads",
        "2",
        "-preset",
        "veryfast",
        "-crf",
        "20",
        "-pix_fmt",
        "yuv420p",
        "-colorspace",
        "bt709",
        "-color_primaries",
        "bt709",
        "-color_trc",
        "bt709",
        "-vf",
        "scale=in_range=pc:out_range=tv:out_color_matrix=bt709",
        str(path),
    ]
    print(STORY[idx]["id"], first, last, flush=True)
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    try:
        for i in range(first, last):
            proc.stdin.write(frame(i / FPS, idx, timeline).tobytes())
        proc.stdin.close()
        if proc.wait():
            raise RuntimeError("FFmpeg encode failed")
    finally:
        if proc.poll() is None:
            proc.kill()


def spans(timeline):
    starts = [math.ceil(x * FPS) for x in timeline["scene_starts"]]
    return list(zip(starts, starts[1:] + [math.ceil(timeline["duration"] * FPS)]))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("work", type=Path)
    parser.add_argument("--scenes", nargs="*", type=int)
    parser.add_argument("--jobs", default=3, type=int)
    parser.add_argument("--contact", type=Path)
    args = parser.parse_args()
    timeline = json.loads((args.work / "timing.json").read_text())
    if args.contact:
        sheet = Image.new("RGB", (6 * 250, math.ceil(len(STORY) / 3) * 445), "#a6ada6")
        for i, scene in enumerate(STORY):
            phrases = [x for x in timeline["phrases"] if x["scene"] == i]
            for j, b in enumerate((0, min(2, len(phrases) - 1))):
                image = frame(phrases[b]["start"] + 0.65, i, timeline)
                thumb = image.resize((246, 437), Image.Resampling.LANCZOS)
                sheet.paste(thumb, ((i % 3 * 2 + j) * 250, (i // 3) * 445))
        sheet.save(args.contact)
        return
    selected = list(range(len(STORY))) if args.scenes is None else args.scenes
    with ProcessPoolExecutor(max_workers=args.jobs) as pool:
        list(
            pool.map(
                section,
                [(args.work, timeline, i, *spans(timeline)[i]) for i in selected],
            )
        )


if __name__ == "__main__":
    main()
