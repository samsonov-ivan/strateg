"""Make a chaptered MP4, readable Russian subtitles and a matching chapter index."""

import json
import math
import re
import subprocess
import sys
import textwrap
from pathlib import Path

HERE = Path(__file__).resolve().parent


def stamp(t, sep=","):
    ms = round(t * 1000)
    return f"{ms // 3600000:02}:{ms // 60000 % 60:02}:{ms // 1000 % 60:02}{sep}{ms % 1000:03}"


def subtitles(timing):
    entries = []
    for phrase in timing["phrases"]:
        punct = re.findall(
            r"[А-Яа-яЁёA-Za-z0-9]+[^А-Яа-яЁёA-Za-z0-9\s]*(?:\s+[—–](?=\s))?",
            phrase["caption"],
        )
        words = phrase["words"]
        if len(punct) != len(words):
            raise ValueError(phrase["caption"])
        # Wrap medium-length, punctuated cues to two lines of at most 39 chars.
        first = 0
        while first < len(words):
            last = first + 1
            while last < len(words):
                next_text = " ".join(punct[first : last + 1])
                if (
                    len(textwrap.wrap(next_text, 39)) > 2
                    or words[last]["end"] - words[first]["start"] > 4.7
                ):
                    break
                last += 1
                if punct[last - 1].endswith((".", "!", "?")):
                    break
            caption = "\n".join(textwrap.wrap(" ".join(punct[first:last]), 39))
            start = words[first]["start"] if first else phrase["start"]
            end = (
                phrase["end"]
                if last == len(words)
                else min(words[last]["start"] - 0.01, words[last - 1]["end"] + 0.1)
            )
            entries.append((start, end, caption))
            first = last
    return (
        "\n\n".join(
            f"{n}\n{stamp(s)} --> {stamp(e)}\n{c}"
            for n, (s, e, c) in enumerate(entries, 1)
        )
        + "\n"
    )


def ff(args):
    subprocess.run(
        ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *map(str, args)],
        check=True,
    )


def main(work, out):
    out.mkdir(exist_ok=True, parents=True)
    timing = json.loads((work / "timing.json").read_text())
    story = json.loads((HERE / "story.json").read_text())
    starts = [math.ceil(v * 30) / 30 for v in timing["scene_starts"]]
    boundaries = starts + [math.ceil(timing["duration"] * 30) / 30]
    # Keep the last packet of each segment at exactly its intended 30 Hz.
    (work / "concat.txt").write_text(
        "".join(
            f"file 'part-{i:02d}.mp4'\nduration {boundaries[i + 1] - start:.12f}\n"
            for i, start in enumerate(starts)
        )
    )
    (work / "chapters.ffmeta").write_text(
        ";FFMETADATA1\ntitle=Стратег — от брифа до пересмотра решения\n"
        + "".join(
            f"[CHAPTER]\nTIMEBASE=1/1000\nSTART={round(start * 1000)}\nEND={round(boundaries[i + 1] * 1000)}\ntitle={s['chapter']}\n"
            for i, (start, s) in enumerate(zip(starts, story))
        )
    )
    (out / "strateg-final.ru.srt").write_text(subtitles(timing))
    (out / "chapters.md").write_text(
        "# Главы конкурсного ролика\n\n"
        + "\n".join(
            f"- {int(t) // 60:02}:{int(t) % 60:02}　{s['chapter']}"
            for t, s in zip(starts, story)
        )
        + "\n"
    )
    audio = HERE / "master.m4a"
    if (work / "mix.wav").exists():
        ff(
            [
                "-i",
                work / "mix.wav",
                "-map_metadata",
                "-1",
                "-c:a",
                "aac",
                "-b:a",
                "192k",
                "-ar",
                "48000",
                audio,
            ]
        )
    if not audio.exists():
        raise SystemExit("Pass a mix.wav in work or retain source/master.m4a")
    ff(
        [
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            work / "concat.txt",
            "-i",
            audio,
            "-i",
            work / "chapters.ffmeta",
            "-map",
            "0:v:0",
            "-map",
            "1:a:0",
            "-map_metadata",
            "2",
            "-map_chapters",
            "2",
            "-c",
            "copy",
            "-metadata:s:a:0",
            "language=rus",
            "-movflags",
            "+faststart",
            out / "strateg-final.mp4",
        ]
    )


if __name__ == "__main__":
    main(*map(Path, sys.argv[1:]))
