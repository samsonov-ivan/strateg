import React from "react";
import {
  AbsoluteFill,
  Img,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import timeline from "../timing.json";
import story from "../story.json";

export const C = {
  ink: "#0e2427",
  deep: "#0c1e21",
  panel: "#19383a",
  line: "#385958",
  mute: "#a4bdb2",
  mint: "#8cecc9",
  lime: "#ecfc57",
  paper: "#f1efe4",
  white: "#fffef5",
  dim: "#4c695e",
  edge: "#bbcabb",
  coral: "#ffb59f",
};
export const U = "Strategy Sans,Arial,sans-serif",
  M = "Strategy Mono,monospace";
export const FPS = 30;
export const total = Math.ceil(timeline.duration * FPS);
export const starts = timeline.scene_starts.map((t) => Math.ceil(t * FPS));
export const model = story;
const phrases = timeline.phrases;
export const at = (n: number, i: number, prefix = "") => {
  const p = phrases.find((x) => x.scene === n && x.beat === i)!;
  const word =
    prefix &&
    p.words.find((w) =>
      w.text.toLocaleLowerCase("ru").startsWith(prefix.toLocaleLowerCase("ru")),
    );
  if (prefix && !word)
    throw new Error("Missing narration anchor " + n + "/" + i + "/" + prefix);
  return Math.round((word ? word.start : p.start) * FPS) - starts[n];
};
export function useWordFrame(n: number) {
  const f = useCurrentFrame();
  return {
    f,
    frames: (beat: number, prefix = "") => f - at(n, beat, prefix),
    absolute: f + starts[n],
  };
}
export const smooth = (frames: number, length = 13) =>
  1 - Math.pow(1 - Math.max(0, Math.min(1, frames / length)), 3);
export function Num({
  v,
  f,
  ms = 22,
  format,
}: {
  v: number;
  f: number;
  ms?: number;
  format?: (v: number) => string;
}) {
  const value = Math.round(v * smooth(f, ms));
  return <>{format ? format(value) : value.toLocaleString("ru-RU")}</>;
}
export function Category({
  children,
  light = false,
}: {
  children: React.ReactNode;
  light?: boolean;
}) {
  return (
    <div
      style={{
        fontFamily: M,
        fontSize: 22,
        letterSpacing: 1,
        color: light ? C.dim : C.mute,
        textTransform: "uppercase",
        lineHeight: 1.3,
      }}
    >
      {children}
    </div>
  );
}
export function Reveal({
  f,
  children,
  delay = 0,
  style = {},
}: {
  f: number;
  children: React.ReactNode;
  delay?: number;
  style?: React.CSSProperties;
}) {
  const v = smooth(f - delay, 15);
  return (
    <div
      style={{
        opacity: v,
        transform: `translateY(${(1 - v) * 18}px)`,
        ...style,
      }}
    >
      {children}
    </div>
  );
}
export function Paper({
  children,
  light = false,
  style = {},
}: {
  children: React.ReactNode;
  light?: boolean;
  style?: React.CSSProperties;
}) {
  return (
    <div
      style={{
        background: light ? C.white : C.panel,
        border: `1.6px solid ${light ? C.edge : C.line}`,
        borderRadius: 17,
        overflow: "hidden",
        ...style,
      }}
    >
      {children}
    </div>
  );
}
export function Title({
  children,
  small = false,
}: {
  children: React.ReactNode;
  small?: boolean;
}) {
  return (
    <div
      style={{
        fontSize: small ? 66 : 82,
        fontWeight: 750,
        lineHeight: 1.02,
        letterSpacing: -3.8,
      }}
    >
      {children}
    </div>
  );
}
export function Side({
  tag,
  title,
  children,
  light = false,
}: {
  tag: string;
  title: React.ReactNode;
  children?: React.ReactNode;
  light?: boolean;
}) {
  return (
    <div style={{ position: "absolute", left: 82, top: 177, width: 602 }}>
      <Category light={light}>{tag}</Category>
      <div style={{ height: 30 }} />
      <Title>{title}</Title>
      {children}
    </div>
  );
}
export function Desk({
  children,
  wide = false,
}: {
  children: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <div
      style={{
        position: "absolute",
        left: wide ? 75 : 747,
        right: 75,
        top: 159,
        bottom: 225,
        display: "flex",
        flexDirection: "column",
        gap: 20,
        justifyContent: "center",
      }}
    >
      {children}
    </div>
  );
}
export function Quote({
  label,
  children,
  light = false,
  tone,
}: {
  label: string;
  children: React.ReactNode;
  light?: boolean;
  tone?: string;
}) {
  return (
    <Paper
      light={light}
      style={{
        padding: "30px 34px",
        position: "relative",
        borderLeft: `7px solid ${tone || (light ? C.dim : C.mint)}`,
      }}
    >
      <Category light={light}>{label}</Category>
      <div
        style={{
          fontSize: 37,
          lineHeight: 1.22,
          marginTop: 16,
          letterSpacing: -0.9,
          fontWeight: 540,
        }}
      >
        {children}
      </div>
    </Paper>
  );
}
export function Row({
  tag,
  children,
  selected = false,
  light = false,
}: {
  tag: string;
  children: React.ReactNode;
  selected?: boolean;
  light?: boolean;
}) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 26,
        padding: "22px 26px",
        minHeight: 83,
        borderBottom: `1.7px solid ${light ? C.edge : C.line}`,
        background: selected ? C.lime : "transparent",
        color: selected ? C.deep : undefined,
      }}
    >
      <span
        style={{ fontFamily: M, fontSize: 22, minWidth: 92, opacity: 0.77 }}
      >
        {tag}
      </span>
      <span
        style={{
          fontSize: 36,
          letterSpacing: -0.9,
          fontWeight: selected ? 720 : 550,
        }}
      >
        {children}
      </span>
    </div>
  );
}
export function Foot({
  children,
  light = false,
}: {
  children: React.ReactNode;
  light?: boolean;
}) {
  return (
    <div
      style={{
        position: "absolute",
        left: 83,
        top: 839,
        right: 80,
        fontSize: 22,
        lineHeight: 1.25,
        color: light ? C.dim : C.mute,
        fontFamily: M,
      }}
    >
      {children}
    </div>
  );
}
export function Asset({
  file,
  style = {},
}: {
  file: string;
  style?: React.CSSProperties;
}) {
  return <Img src={staticFile(file)} style={{ display: "block", ...style }} />;
}
export function Meter({
  value,
  max = 240,
  tone = C.mint,
  light = false,
}: {
  value: number;
  max?: number;
  tone?: string;
  light?: boolean;
}) {
  return (
    <div
      style={{
        position: "relative",
        height: 18,
        borderRadius: 9,
        background: light ? "#d7dcd0" : C.line,
        overflow: "hidden",
      }}
    >
      <div
        style={{
          width: (100 * value) / max + "%",
          height: "100%",
          background: tone,
          borderRadius: 9,
        }}
      />
    </div>
  );
}
export function Caption({ n, light }: { n: number; light: boolean }) {
  const t = (useCurrentFrame() + starts[n]) / FPS;
  const ps = phrases.filter((x) => x.scene === n);
  const p = ps.find((x) => t >= x.start - 0.075 && t <= x.end + 0.13);
  if (!p) return null;
  const tokens =
    p.caption.match(
      /[А-Яа-яЁёA-Za-z0-9]+[^А-Яа-яЁёA-Za-z0-9\s]*(?:\s+[—–](?=\s))?/g,
    ) || [];
  const groups: { start: number; end: number }[] = [];
  for (let i = 0; i < tokens.length; ) {
    let j = i + 1;
    while (
      j < tokens.length &&
      tokens.slice(i, j + 1).join(" ").length <= 55 &&
      j - i < 9 &&
      !/[.!?]$/.test(tokens[j - 1])
    )
      j++;
    groups.push({ start: i, end: j });
    i = j;
  }
  const current = Math.max(0, p.words.filter((w) => w.start <= t).length - 1);
  const g = groups.find((g) => g.end > current) || groups[groups.length - 1];
  return (
    <div
      style={{
        position: "absolute",
        left: 77,
        top: 918,
        right: 77,
        textAlign: "center",
        fontSize: 47,
        fontWeight: 700,
        letterSpacing: -1.7,
        lineHeight: 1.28,
        whiteSpace: "nowrap",
      }}
    >
      {tokens.slice(g.start, g.end).map((w, k) => (
        <span
          key={k}
          style={{
            display: "inline-block",
            padding: "0 7px",
            margin: "0 2px",
            borderRadius: 7,
            background:
              k + g.start === current ? (light ? C.ink : C.lime) : undefined,
            color:
              k + g.start === current ? (light ? C.white : C.deep) : undefined,
          }}
        >
          {w}
        </span>
      ))}
    </div>
  );
}
export function Shell({
  n,
  children,
  light = false,
}: {
  n: number;
  children: React.ReactNode;
  light?: boolean;
}) {
  const f = useCurrentFrame();
  const phase = n < 2 ? 0 : n < 8 ? 1 : n < 10 ? 2 : 3;
  const p = Math.min(1, (starts[n] + f) / total);
  const route = ["Запрос", "Стратегия", "Проверка", "Пересмотр"];
  return (
    <AbsoluteFill
      style={{
        background: light ? C.paper : C.deep,
        color: light ? C.ink : C.paper,
        fontFamily: U,
        overflow: "hidden",
      }}
    >
      <div
        style={{
          position: "absolute",
          left: 80,
          top: 43,
          right: 80,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          borderBottom: `2px solid ${light ? C.edge : C.line}`,
          paddingBottom: 24,
        }}
      >
        <div
          style={{
            display: "flex",
            gap: 14,
            alignItems: "center",
            fontSize: 39,
            fontWeight: 750,
            letterSpacing: -1.4,
          }}
        >
          <div style={{ display: "flex", gap: 6, transform: "skewX(-23deg)" }}>
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                style={{
                  height: 22,
                  width: 8,
                  background: light ? C.ink : C.lime,
                }}
              />
            ))}
          </div>
          Стратег
        </div>
        <div
          style={{
            display: "flex",
            gap: 31,
            alignItems: "center",
            fontSize: 21,
            fontFamily: M,
          }}
        >
          {route.map((s, i) => (
            <div
              key={s}
              style={{
                color:
                  i === phase
                    ? light
                      ? C.ink
                      : C.lime
                    : light
                      ? C.dim
                      : C.mute,
                fontWeight: i === phase ? 700 : 400,
              }}
            >
              {i === phase ? "● " : ""}
              {s}
            </div>
          ))}
        </div>
      </div>
      {children}
      {n > 0 && f < 8 && (
        <div
          style={{
            position: "absolute",
            left: 0,
            top: 133,
            bottom: 220,
            width: 1840 * (1 - smooth(f, 8)),
            background: light ? C.edge : C.panel,
            pointerEvents: "none",
          }}
        />
      )}
      <div
        style={{
          position: "absolute",
          top: 874,
          left: 80,
          right: 80,
          height: 2,
          background: light ? C.edge : C.line,
        }}
      />
      <Caption n={n} light={light} />
      <div
        style={{
          position: "absolute",
          bottom: 27,
          left: 80,
          right: 80,
          height: 4,
          background: light ? C.edge : C.line,
        }}
      >
        <div
          style={{
            width: p * 100 + "%",
            height: "100%",
            background: light ? C.dim : C.mint,
          }}
        />
      </div>
    </AbsoluteFill>
  );
}
