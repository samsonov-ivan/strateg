"""Capture selected, verbatim CLI fields in a Chromium document viewer."""

import argparse
import html
import json
import subprocess
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main(browser):
    docs = [
        (
            "quotes",
            "verify quotes",
            "jq '.data'",
            json.loads((HERE / "quotes.json").read_text())["data"],
        ),
        (
            "check",
            "strategy check",
            "jq '.data | {file,valid_equations,errors}'",
            {
                k: v
                for k, v in json.loads((HERE / "check.json").read_text())[
                    "data"
                ].items()
                if k in ["file", "valid_equations", "errors"]
            },
        ),
    ]
    style = """
    *{box-sizing:border-box}body{background:#172b2d;color:#edf1dd;margin:0;padding:35px 38px;font:29px/1.45 monospace}header{font:23px monospace;color:#b2c8b8;padding-bottom:20px;border-bottom:2px solid #4e6661;margin-bottom:24px}
    .cmd{color:#abbcaa;white-space:pre-wrap;font-size:24px}.out{color:#a7f1d5;white-space:pre-wrap;font-size:34px;line-height:1.45;margin-top:19px}
    """
    with tempfile.TemporaryDirectory() as tmp:
        for key, sub, select, output in docs:
            source = Path(tmp) / "index.html"
            cmd = f"$ python -m strateg {sub} \\\n  --project family-data --json |\n  {select}"
            source.write_text(
                "<meta charset=utf-8><style>"
                + style
                + "</style><header>family-data　 /　 standard output</header><div class=cmd>"
                + html.escape(cmd)
                + "</div><pre class=out>"
                + html.escape(json.dumps(output, ensure_ascii=False, indent=2))
                + "</pre>"
            )
            subprocess.run(
                [
                    browser,
                    "--headless",
                    "--disable-gpu",
                    "--hide-scrollbars",
                    "--no-first-run",
                    f"--user-data-dir={tmp}/profile",
                    "--window-size=870,580",
                    "--screenshot=" + str(HERE / (key + ".png")),
                    source.as_uri(),
                ],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("browser")
    main(parser.parse_args().browser)
