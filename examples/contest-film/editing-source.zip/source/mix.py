"""Mix the unshifted Russian voice with the original diagram cues and master the stereo track."""

import json
import subprocess
import sys
import wave
from pathlib import Path

import numpy as np

work = Path(sys.argv[1])
timeline = json.loads((work / "timing.json").read_text())
starts = timeline["scene_starts"]
sr = 48000
mix = np.zeros((round(timeline["duration"] * sr), 2))
rng = np.random.default_rng(1271)


def place(start, waveform, pan=0.5):
    i = round(start * sr)
    j = min(len(mix), i + len(waveform))
    if i < 0:
        raise ValueError("invalid start")
    for ch, gain in enumerate([np.cos(pan * np.pi / 2), np.sin(pan * np.pi / 2)]):
        mix[i:j, ch] += gain * waveform[: j - i]


def tap(start, hz, pan, level=0.052):
    t = np.arange(0, 0.215, 1 / sr)
    env = (1 - np.exp(-t / 0.004)) * np.exp(-t / 0.044)
    place(
        start,
        level
        * env
        * (np.sin(2 * np.pi * hz * t) + 0.24 * np.sin(2 * np.pi * 1.99 * hz * t)),
        pan,
    )


def whoosh(end):
    t = np.arange(0, 0.27, 1 / sr)
    noise = rng.standard_normal(len(t))
    smooth = np.convolve(noise, np.ones(17) / 17, mode="same") - np.convolve(
        noise, np.ones(69) / 69, mode="same"
    )
    place(end - 0.22, 0.14 * np.sin(np.pi * t / 0.27) ** 2 * smooth, 0.65)
    s = np.arange(0, 0.34, 1 / sr)
    body = (
        np.sin(2 * np.pi * (46 * s + 6.5 * (1 - np.exp(-s * 14))))
        * (1 - np.exp(-s / 0.004))
        * np.exp(-s / 0.074)
    )
    place(end, 0.075 * body, 0.48)



# A sparse three-note score leaves the consonant band free for speech.
# Notes fall in level beneath each spoken phrase, then return in its gaps.
def add_score():
    note_length = 0.94
    t = np.arange(round(sr * note_length)) / sr
    for i, start in enumerate(np.arange(.56, timeline["duration"] - 1.08, 1.56)):
        scene = sum(start >= boundary for boundary in starts[1:])
        chord = ((164.81, 196, 246.94), (146.83, 196, 220),
                 (130.81, 164.81, 196), (146.83, 185, 220))[scene % 4]
        hz = chord[i % 3]
        envelope = (1 - np.exp(-t / .035)) * np.exp(-t / .31)
        spoken = any(p["start"] - .14 <= start <= p["end"] + .06
                     for p in timeline["phrases"])
        amplitude = .009 if spoken else .021
        waveform = amplitude * envelope * (np.sin(2*np.pi*hz*t) + .17*np.sin(4*np.pi*hz*t))
        place(start, waveform, .29 if i % 2 else .67)

add_score()

for boundary in starts[1:]:
    whoosh(boundary)
for phrase in timeline["phrases"]:
    if phrase["beat"] in (1, 3):
        tap(
            phrase["words"][0]["start"],
            (392, 494, 587, 659)[phrase["scene"] % 4],
            0.58,
            0.022,
        )
with wave.open(str(work / "sfx.wav"), "wb") as output:
    output.setparams((2, 2, sr, 0, "NONE", ""))
    output.writeframes(np.clip(mix * 32767, -32767, 32767).astype("<i2").tobytes())
vf = (
    "highpass=f=55,equalizer=f=250:t=q:w=1.15:g=-0.7,equalizer=f=2700:t=q:w=1:g=0.7,"
    "acompressor=threshold=0.19:ratio=1.7:attack=16:release=110:makeup=1.12"
)
pre = f"[0:a]{vf},aresample=48000,pan=stereo|c0=c0|c1=c0[n];[n][1:a]amix=inputs=2:normalize=0:duration=longest"


def ff(args):
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", *args], check=True)


common = ["-i", str(work / "voice.flac"), "-i", str(work / "sfx.wav")]
ff(
    common
    + [
        "-filter_complex",
        pre,
        "-ar",
        "48000",
        "-c:a",
        "pcm_f32le",
        str(work / "premix.wav"),
    ]
)
ln = "loudnorm=I=-15:TP=-1.6:LRA=6"
probe = subprocess.run(
    [
        "ffmpeg",
        "-hide_banner",
        "-nostats",
        "-i",
        str(work / "premix.wav"),
        "-af",
        ln + ":print_format=json",
        "-f",
        "null",
        "-",
    ],
    capture_output=True,
    text=True,
    check=True,
).stderr
stats = json.loads(probe[probe.rfind("{") : probe.rfind("}") + 1])
measured = ":".join(
    k + "=" + stats[v]
    for k, v in [
        ("measured_I", "input_i"),
        ("measured_TP", "input_tp"),
        ("measured_LRA", "input_lra"),
        ("measured_thresh", "input_thresh"),
        ("offset", "target_offset"),
    ]
)
ff(
    [
        "-i",
        str(work / "premix.wav"),
        "-af",
        ln + ":" + measured + ":linear=true",
        "-ar",
        "48000",
        "-c:a",
        "pcm_s24le",
        str(work / "mix.wav"),
    ]
)


ff(
    [
        "-i", str(work / "mix.wav"), "-c:a", "aac", "-b:a", "192k",
        "-movflags", "+faststart", str(work / "master.m4a"),
    ]
)
