# Голос для горизонтального выпуска

Текст прочитан штатным мужским голосом M2 модели Supertonic 3 на русском языке. Команда не записывала живого исполнителя и не использовала голос из присланного видео. Частота основного тона и форманты сохранены при сведении. Низкий регистр принадлежит самому голосу. [Карточка и условия использования модели](https://huggingface.co/Supertone/supertonic-3/blob/3cadd1ee6394adea1bd021217a0e650ede09a323/README.md) · [лицензия весов OpenRAIL-M](https://huggingface.co/Supertone/supertonic-3/blob/3cadd1ee6394adea1bd021217a0e650ede09a323/LICENSE)

Сравнили восемь голосов на одной фразе с твёрдым и мягким «р». У пяти голосов Supertonic независимый Whisper small распознал «руководитель», «проверить», «Стратег пересматривает решение». Побуквенный распознаватель без языковой модели сохранил все 15 вхождений «р» в пробе M2. Медиана основного тона на этой пробе — 94 Гц. Эти тесты оценивают разборчивость. Отрывок из готового мастера позволяет оценить дикцию и тембр на слух.

## Как пересобрать звук

Для повторного монтажа достаточно готовых master.m4a и timing.json. В voice.flac сохранена чистая монофоническая речь до обработки. Сценарий и произносимые тексты находятся в story.json. В timing.json записаны начало и конец каждой реплики, времена слов и начала 13 глав. Слова выровнены с акустическим сигналом каждого дубля по русской модели Wav2Vec2. [Модель для разметки](https://huggingface.co/onnx-community/wav2vec2-large-xlsr-53-russian-ONNX/tree/df5ba1d9e0f9a34c44eec437b441f4ae43c842eb)

Для изменения сценария необходимы Python 3.12 и FFmpeg с фильтром loudnorm и AAC. Следующие команды выполняются из каталога с voice.py и story.json.

```sh
python3 -m venv .venv
.venv/bin/pip install supertonic==1.3.1 numpy scipy soundfile onnxruntime huggingface_hub
.venv/bin/hf download Supertone/supertonic-3 --revision 3cadd1ee6394adea1bd021217a0e650ede09a323 --include 'onnx/*' 'voice_styles/M2.json' --local-dir models/supertonic
.venv/bin/hf download onnx-community/wav2vec2-large-xlsr-53-russian-ONNX --revision df5ba1d9e0f9a34c44eec437b441f4ae43c842eb --include 'onnx/model_quantized.onnx' vocab.json --local-dir models/align
cp models/align/onnx/model_quantized.onnx models/align/model_quantized.onnx
.venv/bin/python voice.py models/supertonic models/align build
.venv/bin/python mix.py build
```

Синтез использует русский языковой код, 16 шагов и скорость 1,065. У каждого дубля фиксированное зерно случайности, привязанное к тексту. Дорожка содержит разборчивый центральный голос, негромкие оригинальные акценты на смене графики и небольшой спад уровня в области 250 Гц. Финальный мастер записан в AAC, стерео, 48 кГц.

Чистая запись длится 238,454 секунды. Медиана основного тона по озвученным кадрам полного текста — 88 Гц. Измерение декодированного AAC дало −15,25 LUFS-I, −1,31 dBTP и диапазон громкости 2,2 LU. Контрольный MP3 содержит непрерывный фрагмент мастера с 00:02,720 по 00:16,280.
