"""Render the 1920 × 1080 contest film from its evidence and speech timings."""
import argparse
import bisect
import json
import math
import os
import subprocess
from concurrent.futures import ProcessPoolExecutor
from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
ART = HERE / "evidence"
STORY = json.loads((HERE / "story.json").read_text())
W, H, FPS = 1920, 1080, 30
DARK, PANEL, INK = "#0e1f22", "#193437", "#183234"
PAPER, WHITE, SOFT = "#f0eee1", "#faf9f0", "#dce2ce"
FADE, DIM, LINE = "#abc0b3", "#455c50", "#45615b"
MINT, GOLD, RED = "#8cecc9", "#ecfc57", "#ffb59f"
LIGHT = {"prompt", "problem", "product", "money", "blind", "change"}
LEFT, RIGHT = 88, 1832
VIS = 802
RW = RIGHT - VIS

def ease(v):
    return 1 - (1 - max(0, min(1, v))) ** 3

@lru_cache(maxsize=512)
def font(size, style):
    files = {"reg":"DejaVuSans", "bold":"DejaVuSans-Bold",
             "heavy":"DejaVuSansCondensed-Bold", "mono":"DejaVuSansMono"}
    path = Path(os.environ.get("STRATEG_FONTS", HERE / "fonts"))
    return ImageFont.truetype(str(path / (files[style]+".ttf")), size)

@lru_cache(maxsize=6000)
def sprite(value, size, color, style):
    ft = font(size, style)
    a, b, c, d = ft.getbbox(value, anchor="lt")
    layer = Image.new("RGBA", (max(1, c-a+4), max(1, d-b+4)))
    ImageDraw.Draw(layer).text((1-a,1-b),value,font=ft,fill=color,anchor="lt")
    return layer

def text(im,x,y,value,size,color,style="reg",maxw=None):
    if maxw:
        size=fit(value,size,style,maxw)
    glyph=sprite(value,size,color,style)
    im.paste(glyph, (round(x),round(y)), glyph)
    return glyph.width

@lru_cache(maxsize=1600)
def fit(value,size,style,width):
    while size>18 and font(size,style).getlength(value)>width:
        size-=1
    return size

@lru_cache(maxsize=1200)
def wrap(value,size,style,width):
    lines=[]
    for word in value.split():
        if lines and font(size,style).getlength(lines[-1]+" "+word)<=width:
            lines[-1]+=" "+word
        else:
            lines.append(word)
    return lines

def para(im,x,y,value,size,color,style,width,leading):
    for row in wrap(value,size,style,width):
        text(im,x,y,row,size,color,style)
        y+=leading
    return y

def box(d,x,y,w,h,fill,r=20,outline=None,width=2):
    d.rounded_rectangle((round(x),round(y),round(x+w),round(y+h)),r,fill=fill,outline=outline,width=width)

def rule(d,x,y,ex,ey,c,w=2):
    d.line((round(x),round(y),round(ex),round(ey)),fill=c,width=w)

def tag(im,d,x,y,s,fill,fg):
    w=font(24,"bold").getlength(s)+44
    box(d,x,y,w,48,fill,24)
    text(im,x+21,y+11,s,24,fg,"bold")
    return w

@lru_cache(maxsize=8)
def asset(name):
    return Image.open(ART/name).convert("RGB")

@lru_cache(maxsize=36)
def fitted(name,w,h):
    a=asset(name)
    scale=min(w/a.width,h/a.height)
    return a.resize((round(a.width*scale),round(a.height*scale)), Image.Resampling.LANCZOS)

def primary(im, val, detail, light, elapsed, *, size=99, y=565, width=665):
    ink,mut=(INK,DIM) if light else (GOLD,FADE)
    x=LEFT + round(19*(1-ease(elapsed/.46)))
    text(im,x,y,val,size,ink,"heavy",width)
    para(im,LEFT,y+105,detail,30,mut,"reg",width,42)

def top(im,d,scene,local,progress):
    light=scene["id"] in LIGHT
    fg,mut,r=(INK,DIM,"#aab8a7") if light else (PAPER,FADE,LINE)
    for i in range(3):
        rule(d,LEFT+i*15,76,LEFT+12+i*15,52,INK if light else GOLD,6)
    text(im,146,41,"Стратег",38,fg,"bold")
    brand="MGIMO × AI CHALLENGE"
    text(im,RIGHT-font(23,"mono").getlength(brand),51,brand,23,mut,"mono")
    rule(d,LEFT,111,RIGHT,111,r)
    title=" ".join(scene["title"])
    offset=round(26*(1-ease(local/.55)))
    para(im,LEFT+offset,177,title,76,fg,"heavy",652,86)
    rule(d,LEFT,864,RIGHT,864,r)
    text(im,LEFT,1006,scene["source"],22,mut,"mono",1530)
    rule(d,LEFT,1052,RIGHT,1052,r,2)
    rule(d,LEFT,1051,LEFT+(RIGHT-LEFT)*max(.003,progress),1051,INK if light else MINT,4)

def gap(im,d,b,p,u):
    vals=["6 млн ₽","1 бриф","4 варианта","1 пересмотр"]
    notes=["разрыв между прогнозом и целью","оператора с семейным тарифом","на выбор руководителю","в новом чате"]
    primary(im,vals[b],notes[b],False,p)
    box(d,VIS,186,RW,538,PANEL,30)
    text(im,VIS+42,229,"Валовая прибыль за год",37,PAPER,"bold")
    rule(d,VIS+42,306,RIGHT-42,306,LINE)
    for i,(number,desc,col) in enumerate([("279","Прогноз без изменений",PAPER),("285","Цель",GOLD)]):
        x=VIS+40+i*516
        text(im,x,367,number,148,col,"heavy",410)
        text(im,x+5,536,"млн ₽",32,col,"bold")
        text(im,x+5,626,desc,28,FADE,"mono",464)
    x=VIS+43
    rule(d,x,773,RIGHT-42,773,LINE,5)
    xx=x+(RW-86)*ease(u/2.8)
    rule(d,x,773,xx,773,MINT,5);d.ellipse((xx-8,765,xx+8,781),fill=MINT)

def prompt(im,d,b,p,u):
    primary(im,["11 страниц","1 документ","Бриф","Проверка"][b],[
        "исходный материал оператора","самостоятельная записка для руководителя",
        "источник сведений в этой задаче","цифр и явных допущений"][b],True,p,size=86)
    box(d,VIS+9,167,RW-9,611,"#d4dacb",24)
    box(d,VIS,158,RW-9,611,WHITE,24,"#b8c5b5")
    text(im,VIS+39,196,"Запрос.txt",39,INK,"bold")
    rule(d,VIS+39,261,RIGHT-48,261,"#c1cdbb")
    parts=[
        "Подготовь по приложенному брифу законченную стратегию для руководителя цифрового продукта.",
        "Отдай её одним самостоятельным документом на русском языке, чтобы руководитель мог принять решение;",
        "Используй только бриф и явно обозначенные собственные предположения. Для проверки вычислений можно пользоваться Python.",
        "цифры и допущения должны быть проверяемыми."
    ]
    # Each quotation is a literal excerpt from the filed request.
    lines = [(s,i==b) for i,s in enumerate(parts[:2])]
    if b==2: lines=[(parts[2],True)]
    if b==3: lines=[(parts[1],False),(parts[3],True)]
    y=309
    for s,active in lines:
        for row in wrap(s,34,"reg",RW-112):
            if active:
                box(d,VIS+32,y-7,font(34,"reg").getlength(row)+22,47,"#d6efbb",6)
            text(im,VIS+42,y,row,34,INK)
            y+=49
        y+=20
    tag(im,d,VIS+40,690,"Исходное сообщение",SOFT,INK)

def evidence(im,d,b,p,u):
    primary(im,["279 млн ₽","285 млн ₽","40 семей","Проверить"][b],[
        "прогноз из брифа","целевая валовая прибыль","в неделю — допущение стратегии",
        "сколько разных семей впервые подходит за неделю"][b],False,p,size=88)
    rows=[("S-001  /  БРИФ","279 млн ₽","Прогноз без изменений"),("S-001  /  БРИФ","285 млн ₽","Целевая валовая прибыль"),("СТРАТЕГИЯ  /  ДОПУЩЕНИЕ","40 в неделю","Впервые подходящие семьи")]
    for i,(ref,v,detail) in enumerate(rows):
        y=159+i*210;active=i==min(b,2)
        x=VIS+round(13*(1-ease(p/.5))) if active else VIS
        box(d,x,y,RW-(x-VIS),183,MINT if active and i<2 else GOLD if active else PANEL,24)
        fg,mu=(INK,DIM) if active else (PAPER,FADE)
        text(im,x+32,y+27,ref,24,mu,"mono")
        text(im,x+28,y+84,v,63,fg,"heavy",513)
        text(im,x+560,y+111,detail,27,mu,"reg",RW-600)

def problem(im,d,b,p,u):
    primary(im,["Две ситуации","Семейный тариф","100 МБ","1 ГБ"][b],[
        "причина перебоя определяет действие","первый сегмент для проверки",
        "условный остаток интернета у близкого","свободный остаток общего пакета"][b],True,p,size=83)
    for i,(name,desc,act) in enumerate([
        ("Семейный тариф","Кончается доля интернета","Можно выдать из общего пакета"),
        ("Собственный роутер","Не проходит оплата","Можно пополнить баланс")]):
        x=VIS;y=164+i*226
        box(d,x,y,RW,197,INK if i==0 else SOFT,25)
        fg,mu=(PAPER,MINT) if i==0 else (INK,DIM)
        text(im,x+34,y+31,name,48,fg,"heavy")
        text(im,x+36,y+120,desc if b<2 else act,31,mu)
    rule(d,VIS,664,RIGHT,664,"#adbdab")
    text(im,VIS,701,"Условие помощи",27,DIM,"mono")
    text(im,VIS,756,"Разрешение участника и свободный пакет",35,INK,"bold",RW)

def options(im,d,b,p,u):
    active=[0,1,2,1][b]
    primary(im,["O-001","O-002","O-003","O-002"][b],[
        "сохранить привычный кабинет","открыть знакомую форму по ссылке","выдать интернет в карточке",
        "проверить сигнал против обычного обслуживания"][b],False,p)
    choices=[("O-001","Обычный кабинет"),("O-002","Предупреждение со ссылкой"),("O-003","Выдача из карточки"),("O-004","Закрыть разработку")]
    for i,(code,title) in enumerate(choices):
        y=161+i*159; on=i==active
        x=VIS+round(14*(1-ease(p/.45))) if on else VIS
        box(d,x,y,RW-(x-VIS),131,GOLD if on else PANEL,23)
        text(im,x+33,y+47,code,25,INK if on else FADE,"mono")
        text(im,x+174,y+41,title,40,INK if on else PAPER,"bold",RW-211)

def phone(im,d,b,p,u):
    states=["До входа","После входа","Отзыв доступа","Устаревший статус"]
    primary(im,states[b],["На экране блокировки виден нейтральный текст.","Остаток видит авторизованный организатор.","Очередь отправки закрывается сразу.","Сигнал семье не отправляется."][b],True,p,size=73)
    x=VIS+65;y=144+round(math.sin(u*.28)*3);pw=576;ph=655
    box(d,x,y,pw,ph,INK,50);box(d,x+13,y+13,pw-26,ph-26,"#e9ecdc",39)
    box(d,x+219,y+28,137,15,INK,7)
    text(im,x+40,y+77,["Экран блокировки","Семейный тариф","Права доступа","Состояние данных"][b],39,INK,"heavy",496)
    text(im,x+42,y+140,["Сообщение организатору","После входа","Настройка участника","Проверка перед отправкой"][b],23,DIM,"mono",490)
    box(d,x+35,y+204,506,240,WHITE,23)
    text(im,x+60,y+234,["Уведомление","Доля участника","Доступ к остатку","Проверка журнала"][b],25,DIM)
    if b==0:
        para(im,x+60,y+292,"У вас новое сообщение в приложении.",38,INK,"bold",459,49)
    elif b==1:
        text(im,x+57,y+290,"100 МБ",62,INK,"heavy")
        text(im,x+60,y+379,"В пакете семьи есть 1 ГБ",25,DIM)
    elif b==2:
        text(im,x+59,y+303,"Отозван",42,INK,"heavy")
        sw=x+398
        box(d,sw,y+294,93,53,"#88978a" if p>.3 else "#289f7a",26)
        knob=sw+round(44-38*ease(p/.7));d.ellipse((knob,y+300,knob+40,y+340),fill=WHITE)
    else: para(im,x+59,y+294,"Статус расчётов устарел",39,INK,"bold",448,48)
    box(d,x+36,y+490,505,82,INK,20)
    text(im,x+58,y+515,["Открыть приложение","Перейти к выдаче","Очередь закрыта","Отправка остановлена"][b],30,MINT,"bold",460)
    rx=x+pw+48
    for i,name in enumerate(["До входа","После входа","Отзыв","Проверка"]):
        yy=266+i*105
        d.ellipse((rx,yy,rx+18,yy+18),fill=INK if i==b else "#b5c3b0")
        text(im,rx+33,yy-4,name,26,INK if i==b else DIM,"bold" if i==b else "reg",290)
    text(im,rx,728,"Макет экрана",22,DIM,"mono",279)

def trial(im,d,b,p,u):
    primary(im,"40 × 6 = 240",["уникальных семей по исходному плану","сначала назначаем целую семью в одну группу","проверяем ограничение интернета через 7 суток","в расчёт входят все назначенные семьи"][b],False,p,size=83)
    for i,(name,c) in enumerate([("Предупреждение",MINT),("Обычный кабинет",GOLD)]):
        x=VIS+i*527; y=205+round((1-ease((u-i*.14)/.65))*18)
        box(d,x,y,502,418,PANEL,29)
        text(im,x+28,y+37,name,32,PAPER,"bold",448)
        text(im,x+23,y+111,"120",104,c,"heavy")
        for j in range(12):
            xx=x+40+j%6*72;yy=y+287+j//6*52
            d.ellipse((xx,yy,xx+21,yy+21),fill=c if u>(j+i)*.11 else LINE)
    rule(d,VIS,685,RIGHT,685,LINE)
    text(im,VIS,731,["Случайное распределение 1 : 1","Контроль получает обычное обслуживание","Исход измеряется по журналу оператора","Включая семьи, которые не открыли сигнал"][b],31,MINT,"bold",RW)

def money(im,d,b,p,u):
    vals=["18","+6 596 ₽","−723 ₽","до 90 000 ₽"]
    primary(im,vals[b],["ожидаемых предотвращённых перебоев","дополнительная валовая прибыль за год до вложений","слабый сценарий за год до вложений","предлагаемый расход на исследование причин"][b],True,p,size=85)
    if b<3:
        box(d,VIS,169,RW,611,INK,29)
        text(im,VIS+39,205,"Два сценария до вложений",40,PAPER,"heavy")
        data=[("Основной","+6 596 ₽",MINT),("Слабый","−723 ₽",RED)]
        for i,(name,v,col) in enumerate(data):
            yy=326+i*165
            text(im,VIS+39,yy,name,29,FADE)
            text(im,VIS+398,yy-8,v,49,col,"heavy")
            zero=VIS+199
            linew=(677 if i==0 else 74)*ease(u/(.9+i*.2))
            rule(d,zero,yy+65,zero,yy+112,FADE,2)
            box(d,zero if i==0 else zero-linew,yy+79,max(2,linew),17,col,8)
        text(im,VIS+40,704,"Добавочная валовая прибыль за год",28,FADE,"mono",RW-76)
    else:
        for i,(q,v,detail) in enumerate([("I квартал","до 90 000 ₽","Установить причины перебоев"),("II квартал","до 482 160 ₽","Отдельное решение о полевом пилоте")]):
            y=176+i*305;fg,sub=(GOLD,MINT) if i==0 else (INK,DIM)
            box(d,VIS,y,RW,267,INK if i==0 else SOFT,27)
            text(im,VIS+37,y+27,q,27,sub,"mono")
            text(im,VIS+33,y+86,v,73,fg,"heavy")
            text(im,VIS+38,y+202,detail,29,PAPER if i==0 else DIM)

def cli(im,d,b,p,u):
    primary(im,["Стратегия.pdf","14 из 14","6 из 6","D-001"][b],["записка руководителю, 8 страниц","исходных цитат подтверждены","размеченных равенств пересчитаны","исходное решение учебной копии"][b],False,p,size=82)
    if b==0:
        x,y=VIS,150;box(d,x,y,RW,657,WHITE,24)
        raw=asset("strategy-page.png")
        cw=raw.width-90; ch=round(cw*(604/(RW-46)))
        ty=48+round(30*ease(p/3.6))
        img=raw.crop((44,ty,44+cw,ty+ch)).resize((RW-46,604),Image.Resampling.LANCZOS)
        im.paste(img,(x+23,y+27))
    elif b in (1,2):
        name="quotes.png" if b==1 else "check.png"
        a=fitted(name,RW,654)
        box(d,VIS,155,RW,657,"#172b2d",20)
        im.paste(a,(VIS+(RW-a.width)//2,155+(657-a.height)//2))
    else:
        for i,(key,s) in enumerate([("D-001","Подготовить условный календарь"),("K-001","Аналитику · 31 марта 2027"),("G1–G4","Согласования открыты")]):
            y=162+i*209;box(d,VIS,y,RW,181,PANEL,25)
            text(im,VIS+33,y+27,key,26,FADE,"mono")
            text(im,VIS+32,y+88,s,44,MINT if i==0 else PAPER,"bold",RW-62)

def blind(im,d,b,p,u):
    primary(im,["Один бриф","2 из 3","10 / 10"][b],[
        "авторы трёх записок были скрыты","модельных рецензентов поставили «Стратега» первым",
        "медианные оценки агента и прежнего сильного ответа"][b],True,p,size=91)
    choices=["Стратег","Стратег","Прежний чат"]
    for i,title in enumerate(choices):
        x=VIS+i*349; yy=210+round((1-ease((u-i*.14)/.65))*28)
        active=(b==1 and i<2) or (b==2 and i==2)
        box(d,x,yy,330,359,INK if active else SOFT,25)
        fg,mu=(PAPER,MINT) if active else (INK,DIM)
        text(im,x+23,yy+36,"Рецензент "+str(i+1),26,mu,"mono",290)
        text(im,x+19,yy+108,"01",92,fg,"heavy")
        text(im,x+23,yy+215,"место",25,mu)
        rule(d,x+22,yy+278,x+307,yy+278,"#789184" if active else "#aabbaa")
        text(im,x+22,yy+304,title,29,fg,"bold",286)
    note=["Три независимые ранжировки для одного брифа.","Медианы баллов: агент 10, новый обычный чат 9.","С прежним сильным ответом преимущество не установлено."][b]
    para(im,VIS,653,note,33,DIM,"reg",RW-15,47)

def chat(im,d,b,p,u):
    primary(im,["family-data","96 / 8 = 12","D-001","D-002"][b],["сохранённое состояние проекта","разных семей в неделю по учебному журналу","прежнее основание требует пересмотра","рабочее решение после пересчёта"][b],False,p,size=81)
    box(d,VIS,158,RW,630,PANEL,28)
    text(im,VIS+36,195,"Выдержка из нового чата",39,PAPER,"bold",RW-74)
    rule(d,VIS+38,266,RIGHT-38,266,LINE)
    if b<2:
        text(im,VIS+37,307,"РУКОВОДИТЕЛЬ  /  УЧЕБНАЯ ПОПРАВКА",24,FADE,"mono",RW-73)
        box(d,VIS+35,369,RW-70,284,"#deebd5",22)
        para(im,VIS+63,406,"«До результата оставляем тот же тариф, шесть недель на набор и семь суток наблюдения после последнего включения».",37,INK,"reg",RW-128,52)
        text(im,VIS+38,705,"96 разных семей · 8 недель журнала",27,MINT,"mono")
    else:
        text(im,VIS+37,307,"СТРАТЕГ  /  ОТВЕТ НОВОГО СЕАНСА",24,FADE,"mono")
        quote=json.loads((ART/"chat.json").read_text())["quote"]
        para(im,VIS+36,391,"«"+quote+"»",43,PAPER,"bold",RW-82,62)
        text(im,VIS+38,705,"Сохранённый проект family-data",27,MINT,"mono")

def change(im,d,b,p,u):
    b=min(b,3)
    primary(im,["12 × 6 = 72","36 + 36","20 недель","72 < 212"][b],[
        "назначения при уточнённом потоке","семей в двух группах вместо 120 + 120",
        "набор 240 семей и ещё 7 суток на исход","до минимальной выборки не хватает 140 семей"][b],True,p,size=85)
    box(d,VIS,165,RW,610,WHITE,27,"#bfccba")
    text(im,VIS+38,201,"Впервые подходящие семьи",42,INK,"heavy")
    text(im,VIS+41,271,"Восемь недель учебной сверки",26,DIM,"mono")
    vals=[10,13,11,14,12,10,15,11];baseline=641
    for i,val in enumerate(vals):
        x=VIS+60+i*117;h=val*15*ease((u-i*.083)/.75)
        box(d,x,baseline-h,70,max(2,h),INK if i%2==0 else "#688677",8)
        text(im,x,baseline-h-40,str(val),28,INK,"bold")
        text(im,x+15,baseline+25,str(i+1),24,DIM,"mono")
    rule(d,VIS+39,baseline+2,RIGHT-38,baseline+2,"#a5b8a5")
    text(im,VIS+40,717,"Неделя",21,DIM,"mono")

def decision(im,d,b,p,u):
    primary(im,["D-002","K-002","≥ 212","G1–G4"][b],[
        "подготовку запуска отложить","аналитик проверяет журнал к 31 марта 2027 года",
        "разных семей за шесть последовательных недель","клиентский трафик и бюджет ждут решения"][b],False,p,size=95)
    for i,(k,v) in enumerate([("D-001 → D-002","Отложить запуск пилота"),("K-002 · АНАЛИТИК · ДО 31 МАРТА 2027","Сверить число подходящих семей"),("УСЛОВИЕ ВОЗВРАТА","≥ 212 семей за 6 недель"),("G1–G4","Ожидают согласования")]):
        y=161+i*157;sl=round(13*(1-ease(p/.5))) if i==b else 0
        active=i==b; fg,mu=(INK,DIM) if active else (PAPER,FADE)
        box(d,VIS+sl,y,RW-sl,132,(MINT if b==2 else GOLD) if active else PANEL,22)
        text(im,VIS+sl+32,y+19,k,23,mu,"mono")
        text(im,VIS+sl+29,y+65,v,42,fg,"heavy",RW-74)

PAINT={"gap":gap,"prompt":prompt,"evidence":evidence,"problem":problem,"options":options,"product":phone,"trial":trial,"money":money,"cli":cli,"blind":blind,"chat":chat,"change":change,"decision":decision}

@lru_cache(maxsize=900)
def chunks(words):
    groups=[];start=0
    while start<len(words):
        end=start+1
        while end<len(words) and end-start<8 and font(47,"bold").getlength(" ".join(words[start:end+1]))+36*(end-start)<1638:
            end+=1
        if len(words)-end==1 and end-start>3: end-=1
        groups.append((start,end));start=end
    return groups

def captions(im,d,phrase,t,light):
    words=phrase["words"]
    active=max(0,bisect.bisect_right([w["start"] for w in words],t)-1)
    lo,hi=next((a,b) for a,b in chunks(tuple(w["text"] for w in words)) if a<=active<b)
    x=LEFT; y=908; fg=INK if light else PAPER
    for j in range(lo,hi):
        value=words[j]["text"]; width=font(47,"bold").getlength(value)
        if j==active:
            box(d,x-8,y-11,width+20,69,INK if light else GOLD,8)
        text(im,x,y,value,47,(PAPER if light else INK) if j==active else fg,"bold")
        x+=width+25

def frame(t,idx,timeline):
    scene=STORY[idx]; phrases=[p for p in timeline["phrases"] if p["scene"]==idx]
    beat=max(0,bisect.bisect_right([p["start"]-.065 for p in phrases],t)-1)
    phrase=phrases[beat];local=t-timeline["scene_starts"][idx];p=max(0,t-phrase["start"])
    light=scene["id"] in LIGHT
    im=Image.new("RGB",(W,H),PAPER if light else DARK);d=ImageDraw.Draw(im)
    top(im,d,scene,local,t/timeline["duration"])
    PAINT[scene["id"]](im,d,beat,p,local)
    # Restrict camera motion to the working pane. The masthead, headline
    # and captions keep their positions while the evidence settles into view.
    pane_box=(VIS-18,139,RIGHT+18,822)
    pane=im.crop(pane_box)
    scale=1 + .012*ease(p/1.15) + .007*ease(local/11)
    vw,vh=pane.width/scale,pane.height/scale
    cx=(pane.width-vw)*(.35 if beat%2 else .67)
    cy=(pane.height-vh)*(.44 if idx%2 else .58)
    im.paste(pane.resize(pane.size,Image.Resampling.BILINEAR,box=(cx,cy,cx+vw,cy+vh)),pane_box[:2])
    # An eight-frame wipe introduces only the evidence pane, leaving title and captions readable.
    if idx and 0<=local<.27:
        total=round(RW*(1-ease(local/.27)))
        if total: d.rectangle((VIS,141,VIS+total,813), fill=INK if light else GOLD)
    captions(im,d,phrase,t,light)
    return im


def section(info):
    work, timeline, idx, first, last = info
    path = Path(work) / f"part-{idx:02d}.mp4"
    cmd = [
        "ffmpeg",
        "-v",
        "error",
        "-y",
        "-f",
        "rawvideo",
        "-pix_fmt",
        "rgb24",
        "-s",
        f"{W}x{H}",
        "-r",
        str(FPS),
        "-i",
        "-",
        "-an",
        "-c:v",
        "libx264",
        "-threads",
        "2",
        "-preset",
        "veryfast",
        "-crf",
        "20",
        "-pix_fmt",
        "yuv420p",
        "-colorspace",
        "bt709",
        "-color_primaries",
        "bt709",
        "-color_trc",
        "bt709",
        "-vf",
        "scale=in_range=pc:out_range=tv:out_color_matrix=bt709",
        str(path),
    ]
    print(STORY[idx]["id"], first, last, flush=True)
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    try:
        for i in range(first, last):
            proc.stdin.write(frame(i / FPS, idx, timeline).tobytes())
        proc.stdin.close()
        if proc.wait():
            raise RuntimeError("FFmpeg encode failed")
    finally:
        if proc.poll() is None:
            proc.kill()


def spans(timeline):
    starts = [math.ceil(x * FPS) for x in timeline["scene_starts"]]
    return list(zip(starts, starts[1:] + [math.ceil(timeline["duration"] * FPS)]))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("work", type=Path)
    parser.add_argument("--scenes", nargs="*", type=int)
    parser.add_argument("--jobs", default=3, type=int)
    parser.add_argument("--contact", type=Path)
    args = parser.parse_args()
    timeline = json.loads((args.work / "timing.json").read_text())
    if args.contact:
        sheet = Image.new("RGB", (3 * 488, math.ceil(len(STORY) / 3) * 277), "#61776d")
        for i, scene in enumerate(STORY):
            phrases = [x for x in timeline["phrases"] if x["scene"] == i]
            selected = 2 if i in (2, 5, 8, 10, 11, 12) else 1
            img = frame(phrases[selected]["start"] + .65, i, timeline)
            sheet.paste(img.resize((480, 270), Image.Resampling.LANCZOS), ((i % 3) * 488 + 4, (i // 3) * 277 + 3))
        sheet.save(args.contact)
        return
    selected = list(range(len(STORY))) if args.scenes is None else args.scenes
    with ProcessPoolExecutor(max_workers=args.jobs) as pool:
        list(
            pool.map(
                section,
                [(args.work, timeline, i, *spans(timeline)[i]) for i in selected],
            )
        )


if __name__ == "__main__":
    main()
