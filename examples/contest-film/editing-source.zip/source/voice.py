"""Render Russian voice takes and align them to the actual speech waveform."""
import argparse
import hashlib
import json
import math
import re
from pathlib import Path

import numpy as np
import onnxruntime as ort
import soundfile as sf
from scipy.signal import resample_poly
from supertonic import TTS

STYLE = "M2"
SPEED = 1.065
STEPS = 16
HERE = Path(__file__).resolve().parent


def trim(audio, rate):
    active = np.flatnonzero(np.abs(audio) > 0.006)
    if len(active) == 0:
        raise ValueError("Silent take")
    start = max(0, active[0] - round(rate * 0.070))
    end = min(len(audio), active[-1] + round(rate * 0.105))
    take = audio[start:end].copy()
    fade = round(rate * 0.005)
    take[:fade] *= np.linspace(0, 1, fade)
    take[-fade:] *= np.linspace(1, 0, fade)
    return take


def ctc_session(folder, threads):
    options = ort.SessionOptions()
    options.intra_op_num_threads = threads
    options.inter_op_num_threads = 1
    session = ort.InferenceSession(
        str(folder / "model_quantized.onnx"), options, providers=["CPUExecutionProvider"],
    )
    return session, json.loads((folder / "vocab.json").read_text())


def forced_words(audio, rate, caption, session, vocab):
    divisor = math.gcd(rate, 16000)
    waveform = resample_poly(audio, 16000 // divisor, rate // divisor)
    waveform = (waveform - waveform.mean()) / np.sqrt(waveform.var() + 1e-7)
    scores = session.run(["logits"], {"input_values": waveform[None].astype("float32")})[0][0]
    words = re.findall(r"[А-Яа-яЁё]+", caption)
    spelling = "|".join(words).lower()
    labels = np.zeros(2 * len(spelling) + 1, dtype=int)
    labels[1::2] = [vocab[ch] for ch in spelling]
    can_skip = np.zeros(len(labels), dtype=bool)
    can_skip[2:] = (labels[2:] != 0) & (labels[2:] != labels[:-2])
    previous = np.full(len(labels), -np.inf)
    previous[0] = 0
    back = np.zeros((len(scores), len(labels)), dtype=np.uint8)
    for index, frame in enumerate(scores):
        choices = np.full((3, len(labels)), -np.inf)
        choices[0] = previous
        choices[1, 1:] = previous[:-1]
        choices[2, 2:] = previous[:-2]
        choices[2, ~can_skip] = -np.inf
        back[index] = choices.argmax(axis=0)
        previous = choices.max(axis=0) + frame[labels]
    state = len(labels) - 2 + int(previous[-1] > previous[-2])
    if not np.isfinite(previous[state]):
        raise ValueError(f"Unable to align take: {caption}")
    path = np.empty(len(scores), dtype=int)
    for index in range(len(scores) - 1, -1, -1):
        path[index] = state
        state -= int(back[index, state])
    # Each acoustic frame covers 20 ms. CTC character peaks tend to land toward
    # the vowel. Keep a little of the neighbouring blank for the highlighted word.
    result = []
    char_index = 0
    for word in words:
        first = char_index * 2 + 1
        last = (char_index + len(word) - 1) * 2 + 1
        indices = np.flatnonzero((path >= first) & (path <= last))
        lo = max(0, (indices[0] * 320 + 200) / 16000 - .045)
        hi = min(len(audio) / rate, (indices[-1] * 320 + 200) / 16000 + .065)
        if result and result[-1][2] > lo:
            middle = (result[-1][2] + lo) / 2
            result[-1][2] = lo = middle
        result.append([word, lo, hi])
        char_index += len(word) + 1
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("model", type=Path, help="Directory containing Supertonic 3 onnx/ and voice_styles/")
    parser.add_argument("ctc", type=Path, help="Directory containing Russian model_quantized.onnx and vocab.json")
    parser.add_argument("work", type=Path)
    parser.add_argument("--threads", type=int, default=4)
    args = parser.parse_args()
    args.work.mkdir(parents=True, exist_ok=True)
    cache = args.work / "takes"
    cache.mkdir(exist_ok=True)
    story = json.loads((HERE / "story.json").read_text())
    tts = TTS(model_dir=args.model, auto_download=False, intra_op_num_threads=args.threads, inter_op_num_threads=1)
    voice = tts.get_voice_style(STYLE)
    rate = tts.sample_rate
    aligner, vocab = ctc_session(args.ctc, args.threads)
    pieces, starts, phrases = [], [], []
    position = 0

    def append(piece):
        nonlocal position
        pieces.append(piece)
        position += len(piece)

    def pause(seconds):
        append(np.zeros(round(rate * seconds), dtype=np.float32))

    pause(.22)
    for sid, scene in enumerate(story):
        starts.append(0 if sid == 0 else round(position / rate - .22, 3))
        for beat, caption in enumerate(scene["speech"]):
            reading = scene.get("readings", {}).get(str(beat), caption)
            seed = int(hashlib.sha256(reading.encode()).hexdigest()[:8], 16)
            key = hashlib.sha256(f"{STYLE}|{SPEED}|{STEPS}|{seed}|{reading}".encode()).hexdigest()[:12]
            file = cache / f"{sid:02d}-{beat:02d}-{key}.flac"
            if not file.exists():
                np.random.seed(seed)
                output, _ = tts.synthesize(reading, voice, total_steps=STEPS, speed=SPEED, lang="ru")
                sf.write(file, trim(output.reshape(-1), rate), rate, subtype="PCM_24")
            take, stored_rate = sf.read(file, dtype="float32")
            if stored_rate != rate:
                raise ValueError(f"Take has unexpected sample rate: {file}")
            marks = forced_words(take, rate, caption, aligner, vocab)
            start = position / rate
            append(take)
            phrases.append({
                "scene": sid, "beat": beat, "start": round(start, 3), "end": round(position / rate, 3),
                "caption": caption, "words": [
                    {"text": word, "start": round(start + lo, 3), "end": round(start + hi, 3)}
                    for word, lo, hi in marks
                ],
            })
            pause(scene.get("beat_pauses", {}).get(str(beat), .54 if beat == len(scene["speech"]) - 1 else .18))
        print(scene["id"], round(position / rate, 2), flush=True)
    pause(.45)
    sf.write(args.work / "voice.flac", np.concatenate(pieces), rate, subtype="PCM_24")
    timeline = {"duration": position / rate, "scene_starts": starts, "phrases": phrases}
    (args.work / "timing.json").write_text(json.dumps(timeline, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()
