import React from "react";
import {
  C,
  M,
  Category,
  Title,
  Desk,
  Side,
  Paper,
  Quote,
  Row,
  Foot,
  Asset,
  Meter,
  Reveal,
  Num,
  smooth,
  useWordFrame,
} from "./kit";

const body: React.CSSProperties = {
  fontSize: 32,
  lineHeight: 1.27,
  letterSpacing: -0.65,
};
const metric: React.CSSProperties = {
  fontSize: 100,
  lineHeight: 1,
  letterSpacing: -5,
  fontWeight: 750,
  fontVariantNumeric: "tabular-nums",
};
function Blurb({ children }: { children: React.ReactNode }) {
  return <div style={{ marginTop: 40, ...body }}>{children}</div>;
}
function Labels({
  a,
  b,
  light = false,
}: {
  a: string;
  b: string;
  light?: boolean;
}) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "20px 28px",
        background: light ? "#dce4d6" : C.panel,
        color: light ? C.dim : C.mute,
        fontFamily: M,
        fontSize: 20,
      }}
    >
      <span>{a}</span>
      <span>{b}</span>
    </div>
  );
}
function Gap() {
  const { f, frames } = useWordFrame(0);
  const vals = [
    { name: "Прогноз", v: 279 },
    { name: "Цель", v: 285 },
  ];
  return (
    <>
      <div style={{ position: "absolute", left: 80, top: 181, width: 755 }}>
        <Category>Решение руководителя продукта</Category>
        <div style={{ height: 42 }} />
        <Title>
          До цели
          <br />
          не хватает
        </Title>
        <div style={{ ...metric, color: C.lime, fontSize: 144, marginTop: 18 }}>
          <Num v={6} f={f} ms={17} /> млн ₽
        </div>
        <Reveal f={frames(1)}>
          <Blurb>Во что вложиться первым?</Blurb>
        </Reveal>
      </div>
      <div style={{ position: "absolute", left: 918, right: 82, top: 216 }}>
        <Category>Годовая валовая прибыль · млн ₽</Category>
        {vals.map((x, i) => (
          <div key={x.name} style={{ marginTop: 44 }}>
            <div
              style={{
                display: "flex",
                alignItems: "baseline",
                justifyContent: "space-between",
              }}
            >
              <span style={{ fontSize: 36 }}>{x.name}</span>
              <strong
                style={{
                  fontSize: 84,
                  color: i ? C.mint : C.paper,
                  lineHeight: 1.2,
                }}
              >
                <Num v={x.v} f={f - i * 7} ms={27} />
              </strong>
            </div>
            <Meter
              value={x.v * smooth(f - i * 7, 28)}
              max={300}
              tone={i ? C.mint : C.mute}
            />
          </div>
        ))}
        <Reveal
          f={frames(3)}
          style={{ marginTop: 62, fontSize: 27, fontFamily: M, color: C.mute }}
        >
          Бриф → выбор → новые данные
        </Reveal>
      </div>
      <Foot>Бриф оператора · с. 3</Foot>
    </>
  );
}
function Prompt() {
  const { f, frames } = useWordFrame(1);
  const b = frames(1) >= 0;
  return (
    <>
      <Side
        light
        tag="Исходный запрос"
        title={
          <>
            Один бриф.
            <br />
            Одно решение.
          </>
        }
      >
        <Blurb>
          Руководитель цифрового продукта передаёт агенту 11 страниц.
        </Blurb>
      </Side>
      <Desk>
        <Paper light style={{ height: 600 }}>
          <Labels
            a={b ? "Запрос.txt" : "Бриф.pdf · с. 3 из 11"}
            b="Исходный материал"
            light
          />
          {b ? (
            <div style={{ padding: "36px 43px" }}>
              <Category light>Из сообщения руководителя</Category>
              <div
                style={{
                  fontSize: 41,
                  lineHeight: 1.2,
                  letterSpacing: -1,
                  marginTop: 22,
                }}
              >
                «Подготовь по приложенному брифу законченную стратегию для
                руководителя цифрового продукта».
              </div>
              <Reveal
                f={frames(2)}
                style={{
                  marginTop: 30,
                  ...body,
                  borderLeft: `6px solid ${C.dim}`,
                  paddingLeft: 23,
                }}
              >
                «Используй только бриф и явно обозначенные собственные
                предположения».
              </Reveal>
              <Reveal
                f={frames(3)}
                style={{
                  marginTop: 28,
                  fontFamily: M,
                  fontSize: 23,
                  color: C.dim,
                }}
              >
                Каждое число → источник или допущение
              </Reveal>
            </div>
          ) : (
            <div
              style={{ height: 520, overflow: "hidden", background: "white" }}
            >
              <Asset
                file="brief3.jpg"
                style={{
                  width: "89%",
                  margin: "18px auto",
                  transform: `translateY(${-120 * smooth(f, 72)}px)`,
                }}
              />
            </div>
          )}
        </Paper>
      </Desk>
      <Foot light>family-data / materials / inbox</Foot>
    </>
  );
}
function Evidence() {
  const { f, frames } = useWordFrame(2);
  const obs = frames(2, "сорок");
  return (
    <>
      <Side
        tag="Реестр оснований"
        title={
          <>
            Откуда
            <br />
            взялись числа
          </>
        }
      >
        <Blurb>Одно из них определит, можно ли проводить пилот.</Blurb>
      </Side>
      <Desk>
        <Paper>
          <Labels a="Стратегия / основания" b="Источник" />
          <Row tag="279 млн ₽">Прогноз без изменений</Row>
          <Reveal f={frames(1)}>
            <Row tag="285 млн ₽">Цель на конец года</Row>
          </Reveal>
        </Paper>
        <Reveal f={obs}>
          <Paper
            style={{ background: C.lime, padding: "30px 34px", color: C.deep }}
          >
            <Category light>Допущение первого сеанса</Category>
            <div
              style={{
                display: "flex",
                gap: 34,
                alignItems: "center",
                marginTop: 14,
              }}
            >
              <strong style={{ ...metric, fontSize: 96 }}>
                <Num f={obs} v={40} />
              </strong>
              <span style={{ fontSize: 38, lineHeight: 1.13 }}>
                подходящих семей
                <br />в неделю
              </span>
            </div>
          </Paper>
        </Reveal>
      </Desk>
      <Foot>
        Бриф оператора · с. 3 / Допущение о потоке семей · исходный план
      </Foot>
    </>
  );
}
function Situations() {
  const { f, frames } = useWordFrame(3);
  const pick = frames(1) > 0;
  return (
    <>
      <Side
        light
        tag="Выбор клиента"
        title={
          <>
            Кому ещё
            <br />
            успеют помочь?
          </>
        }
      >
        <Blurb>Момент для действия возникает до перебоя.</Blurb>
      </Side>
      <Desk>
        <Paper
          light
          style={{
            padding: "32px 34px",
            borderLeft: `8px solid ${pick ? C.dim : C.edge}`,
          }}
        >
          <Category light>
            {pick ? "Выбрано для первой проверки" : "Ситуация 01"}
          </Category>
          <div style={{ fontSize: 51, fontWeight: 700, margin: "14px 0" }}>
            Семейный тариф
          </div>
          <div style={body}>У близкого заканчивается интернет.</div>
          <Reveal
            f={frames(2)}
            style={{
              marginTop: 24,
              paddingTop: 20,
              borderTop: `1px solid ${C.edge}`,
              ...body,
            }}
          >
            Свободный пакет есть. Организатор вправе видеть остаток и помочь.
          </Reveal>
        </Paper>
        <Paper light style={{ padding: "24px 34px", opacity: pick ? 0.66 : 1 }}>
          <Category light>Альтернативная ситуация</Category>
          <div style={{ fontSize: 35, fontWeight: 650, marginTop: 12 }}>
            У владельца роутера срывается оплата.
          </div>
        </Paper>
      </Desk>
      <Foot light>Стратегия · раздел 2 «Когда оператор может помочь»</Foot>
    </>
  );
}
const options = [
  "Оставить обычный кабинет",
  "Предупредить и открыть знакомую форму",
  "Выдать интернет прямо из карточки",
  "Закрыть разработку",
];
function Options() {
  const { f, frames } = useWordFrame(4);
  const show = [f, frames(1), frames(2), frames(2, "закрыть")];
  return (
    <>
      <Side
        tag="Четыре варианта"
        title={
          <>
            Какое действие
            <br />
            проверим?
          </>
        }
      >
        <Reveal f={frames(3)}>
          <Blurb>Ссылку проверят на фоне обычного кабинета.</Blurb>
        </Reveal>
      </Side>
      <Desk>
        <Paper>
          <Labels a="Реестр вариантов" b="family-data" />
          {options.map((x, i) => (
            <Reveal key={x} f={show[i]}>
              <Row tag={"O-00" + (i + 1)} selected={i === 1 && frames(3) >= 0}>
                {x}
              </Row>
            </Reveal>
          ))}
        </Paper>
      </Desk>
      <Foot>Стратегия · раздел 4 / Обычное обслуживание служит контролем</Foot>
    </>
  );
}
function Product() {
  const { f, frames } = useWordFrame(5);
  const a = frames(1) > 0,
    b = frames(2) > 0;
  return (
    <>
      <Side
        light
        tag="Продукт и коммуникация"
        title={
          <>
            Что увидит
            <br />
            организатор
          </>
        }
      >
        <Blurb>
          {b
            ? "При отзыве доступа сведения сразу исчезают."
            : a
              ? "После входа появляется остаток и ссылка в привычную форму."
              : "На экране блокировки нет чужого остатка и имени."}
        </Blurb>
      </Side>
      <Desk>
        <div
          style={{
            display: "flex",
            height: 615,
            alignItems: "center",
            justifyContent: "space-around",
            gap: 24,
          }}
        >
          <div
            style={{
              width: 378,
              height: 590,
              border: `11px solid ${C.ink}`,
              borderRadius: 52,
              background: b ? "#dde6da" : C.white,
              padding: 31,
              boxSizing: "border-box",
              position: "relative",
              boxShadow: "0 10px 0 #cad1c4",
            }}
          >
            <div
              style={{
                width: 75,
                height: 12,
                margin: "0 auto 39px",
                background: C.ink,
                borderRadius: 10,
              }}
            />
            <Category light>
              {b ? "Доступ" : a ? "Семейный пакет" : "Уведомление"}
            </Category>
            <div
              style={{
                fontSize: 36,
                fontWeight: 750,
                lineHeight: 1.1,
                marginTop: 28,
              }}
            >
              {b
                ? "Доступ отозван"
                : a
                  ? "Можно помочь близкому"
                  : "Откройте кабинет"}
            </div>
            <div
              style={{
                fontSize: 23,
                lineHeight: 1.3,
                marginTop: 24,
                color: C.dim,
              }}
            >
              {b
                ? "Данные участника скрыты."
                : a
                  ? "У близкого мало интернета. В общем пакете есть свободный остаток."
                  : "Появилось обновление по семейному тарифу."}
            </div>
            {!b && (
              <div
                style={{
                  position: "absolute",
                  bottom: 49,
                  left: 27,
                  right: 27,
                  padding: "19px 11px",
                  background: a ? C.ink : C.lime,
                  color: a ? C.white : C.ink,
                  textAlign: "center",
                  fontWeight: 700,
                  fontSize: 24,
                  borderRadius: 13,
                }}
              >
                {a ? "Открыть форму" : "Войти в кабинет"}
              </div>
            )}
          </div>
          <div style={{ width: 485 }}>
            <Category light>Сценарий семьи</Category>
            {[
              "Нейтральное сообщение",
              "Действие после входа",
              "Отзыв разрешения",
            ].map((x, i) => (
              <div
                key={x}
                style={{
                  padding: "26px 0",
                  borderBottom: `1px solid ${C.edge}`,
                  fontSize: 30,
                  opacity:
                    (i === 0 && !a) || (i === 1 && a && !b) || (i === 2 && b)
                      ? 1
                      : 0.5,
                  fontWeight:
                    (i === 0 && !a) || (i === 1 && a && !b) || (i === 2 && b)
                      ? 750
                      : 450,
                }}
              >
                {x}
              </div>
            ))}
          </div>
        </div>
      </Desk>
      <Foot light>
        Иллюстрация предлагаемого интерфейса · стратегия, раздел 3
      </Foot>
    </>
  );
}
function Trial() {
  const { f, frames } = useWordFrame(6);
  return (
    <>
      <Side
        tag="Первый план пилота"
        title={
          <>
            Семья входит
            <br />в одну группу
          </>
        }
      >
        <Blurb>
          Шесть недель набора, затем семь суток наблюдения после последнего
          включения.
        </Blurb>
      </Side>
      <Desk>
        <Paper style={{ padding: "32px 36px" }}>
          <Category>Предполагаемый поток × окно набора</Category>
          <div style={{ ...metric, color: C.lime, marginTop: 20 }}>
            40 × 6 = <Num f={f} v={240} />
          </div>
          <div style={{ ...body, marginTop: 20 }}>
            назначений по одному тарифу
          </div>
        </Paper>
        <Reveal f={frames(1)}>
          <div style={{ display: "flex", gap: 18 }}>
            {["Предупреждение", "Обычный кабинет"].map((s, i) => (
              <Paper key={s} style={{ flex: 1, padding: "24px 29px" }}>
                <div
                  style={{
                    fontSize: 56,
                    fontWeight: 720,
                    color: i ? C.paper : C.mint,
                  }}
                >
                  120
                </div>
                <div style={{ fontSize: 27, marginTop: 6 }}>{s}</div>
              </Paper>
            ))}
          </div>
        </Reveal>
        <Reveal
          f={frames(2)}
          style={{ fontSize: 26, lineHeight: 1.3, color: C.mute }}
        >
          Журнал оператора фиксирует исход по каждой назначенной семье.
        </Reveal>
      </Desk>
      <Foot>Первоначальный план · допущение о 40 новых семьях в неделю</Foot>
    </>
  );
}
function Money() {
  const { frames } = useWordFrame(7);
  return (
    <>
      <Side
        light
        tag="Экономика решения"
        title={
          <>
            Сколько даст
            <br />
            этот сигнал?
          </>
        }
      >
        <Blurb>Годовая дополнительная валовая прибыль до вложений.</Blurb>
      </Side>
      <Desk>
        <Paper light style={{ padding: "35px 38px" }}>
          <Category light>Основной учебный сценарий</Category>
          <div style={{ ...metric, color: C.ink, marginTop: 16 }}>
            +<Num f={Math.max(0, frames(0))} v={6596} /> ₽
          </div>
          <div style={{ ...body, color: C.dim, marginTop: 12 }}>
            18 предотвращённых перебоев
          </div>
        </Paper>
        <Reveal f={frames(2)}>
          <Paper
            light
            style={{
              padding: "22px 36px",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <span style={body}>Слабый сценарий</span>
            <strong style={{ fontSize: 60 }}>−723 ₽</strong>
          </Paper>
        </Reveal>
        <Reveal
          f={frames(3)}
          style={{ padding: "20px 4px", fontSize: 34, fontWeight: 680 }}
        >
          До 90 000 ₽ — на исследование причин.
        </Reveal>
      </Desk>
      <Foot light>Модель прибыли · два сценария, исходные допущения</Foot>
    </>
  );
}
function Output() {
  const { f, frames } = useWordFrame(8);
  const b = frames(1) >= 0,
    c = frames(2) >= 0,
    d = frames(3) >= 0;
  return (
    <>
      <Side
        tag={
          d
            ? "Архив проекта"
            : b
              ? "Проверки первого сеанса"
              : "Готовый документ"
        }
        title={
          d ? (
            <>
              Что можно
              <br />
              открыть снова
            </>
          ) : b ? (
            <>
              Проверить
              <br />
              каждый вывод
            </>
          ) : (
            <>
              Готовая
              <br />
              стратегия
            </>
          )
        }
      >
        <Blurb>
          {d
            ? "Сохранены записка, решения и история диалога."
            : b
              ? "Агент сверяет цитаты и заново считает равенства."
              : "Один документ связывает проблему, действие, экономику и план."}
        </Blurb>
      </Side>
      <Desk>
        {d ? (
          <Paper>
            <Labels a="04-Демопроект.zip" b="Состав архива" />
            {[
              ["out/", "strategy.md"],
              ["state/", "decisions.jsonl"],
              ["history/", "new-session.jsonl"],
            ].map(([a, b], i) => (
              <Reveal key={a} f={frames(3) - i * 3}>
                <Row tag={a}>{b}</Row>
              </Reveal>
            ))}
          </Paper>
        ) : b ? (
          <Paper>
            <Labels
              a="Терминал · сохранённый вывод"
              b={c ? "strateg strategy check" : "strateg verify quotes"}
            />
            <div
              style={{ height: 465, overflow: "hidden", background: "#152b30" }}
            >
              <Asset
                file={c ? "check.png" : "quotes.png"}
                style={{ width: "100%", height: 465, objectFit: "contain" }}
              />
            </div>
          </Paper>
        ) : (
          <Paper
            style={{
              background: "white",
              transform: `rotate(${-1.1 + 0.7 * smooth(f, 65)}deg)`,
            }}
          >
            <Labels a="Стратегия.pdf" b="Страница 1" />
            <div style={{ height: 486, overflow: "hidden" }}>
              <Asset
                file="strategy.png"
                style={{
                  width: "123%",
                  maxWidth: "none",
                  marginLeft: "-7.1%",
                  transform: `translateY(${-8 - 65 * smooth(f, 110)}px)`,
                }}
              />
            </div>
          </Paper>
        )}
      </Desk>
      <Foot>
        family-data / out / strategy.md · сохранённые файлы и действительный
        вывод команд
      </Foot>
    </>
  );
}
function Blind() {
  const { f, frames } = useWordFrame(9);
  const chosen = frames(1) >= 0;
  return (
    <>
      <Side
        light
        tag="Слепая проверка"
        title={
          <>
            Один бриф.
            <br />
            Три рецензента.
          </>
        }
      >
        <Blurb>Каждый модельный рецензент получил обезличенные записки.</Blurb>
      </Side>
      <Desk>
        <Paper light>
          <Labels a="Первое место у рецензента" b="Один учебный бриф" light />
          {["Стратег", "Стратег", "Обычный чат"].map((s, i) => (
            <Row light tag={"0" + (i + 1)} key={i} selected={chosen && i < 2}>
              {(i < 2 ? chosen : frames(2) >= 0) ? s : "Ответ скрыт"}
            </Row>
          ))}
        </Paper>
        <Reveal
          f={frames(2)}
          style={{ fontSize: 32, lineHeight: 1.28, color: C.dim }}
        >
          Третьему рецензенту не хватило сопоставимых данных по двум сегментам.
        </Reveal>
      </Desk>
      <Foot light>
        21 ноября 2026 · внутреннее сравнение ответов на одном брифе
      </Foot>
    </>
  );
}
const weeks = [10, 13, 11, 14, 12, 10, 15, 11];
function Chat() {
  const { f, frames } = useWordFrame(10);
  const journal = frames(1) >= 0;
  const answer = frames(3) >= 0;
  return (
    <>
      <Side
        tag="Продолжение после перерыва"
        title={
          <>
            Новый чат.
            <br />
            Тот же проект.
          </>
        }
      >
        <Blurb>
          {answer
            ? "Агент восстанавливает прежнее решение и меняет его по сохранённым основаниям."
            : journal
              ? "Впервые подошедшие семьи считают по одному разу за восемь недель."
              : "Руководитель открывает сохранённый демопроект."}
        </Blurb>
      </Side>
      <Desk>
        {!journal ? (
          <Paper>
            <Labels a="Демопроект / history" b="Сохранённые сеансы" />
            <Row tag="01">first-session.json</Row>
            <Row tag="02" selected>
              new-session.jsonl
            </Row>
          </Paper>
        ) : answer ? (
          <Quote label="Из ответа отдельного сеанса · дословно" tone={C.lime}>
            «Подготовку запуска стоит отложить. В учебном журнале за восемь
            недель впервые подошли 96 разных семей — в среднем 12 в неделю».
          </Quote>
        ) : (
          <Paper>
            <Labels a="Поправка.md" b="Учебное уточнение руководителя" />
            <div style={{ padding: "28px 34px" }}>
              <div style={{ fontSize: 34, fontWeight: 650 }}>
                Число новых семей по неделям
              </div>
              <div
                style={{
                  display: "flex",
                  alignItems: "flex-end",
                  gap: 15,
                  height: 177,
                  margin: "27px 0 20px",
                }}
              >
                {weeks.map((v, i) => (
                  <div
                    key={i}
                    style={{
                      display: "flex",
                      flex: 1,
                      flexDirection: "column",
                      alignItems: "center",
                      gap: 8,
                    }}
                  >
                    <span
                      style={{ fontSize: 27, fontFamily: M, color: C.mint }}
                    >
                      {v}
                    </span>
                    <div
                      style={{
                        height: v * 7 * smooth(frames(1) - i * 2, 17),
                        width: "85%",
                        background: i === 7 ? C.lime : C.mint,
                        borderRadius: "5px 5px 0 0",
                      }}
                    />
                    <span
                      style={{ fontFamily: M, fontSize: 16, color: C.mute }}
                    >
                      {i + 1}
                    </span>
                  </div>
                ))}
              </div>
              <div style={{ fontSize: 34, color: C.paper }}>
                96 ÷ 8 ={" "}
                <strong style={{ color: C.lime }}>12 семей в неделю</strong>
              </div>
            </div>
          </Paper>
        )}
        {frames(2) >= 0 && !answer && (
          <Reveal f={frames(2)}>
            <Quote label="Из поправки · дословно">
              «Руководитель просит пересмотреть условный календарь пилота».
            </Quote>
          </Reveal>
        )}
      </Desk>
      <Foot>
        Выдержки из материалов и экспорта нового чата · учебная сверка
      </Foot>
    </>
  );
}
function Revision() {
  const { f, frames } = useWordFrame(11);
  const gap = frames(3, "сто");
  const right = smooth(f, 28);
  const diff = gap >= 0;
  return (
    <>
      <Side
        light
        tag="Пересчёт набора"
        title={
          <>
            Почему пилот
            <br />
            откладывают
          </>
        }
      >
        <div style={{ marginTop: 47 }}>
          <Category light>Поток за одну неделю</Category>
          <div style={{ ...metric, fontSize: 84, marginTop: 10 }}>
            40 <span style={{ color: C.dim }}>→</span> 12
          </div>
        </div>
        <Reveal f={frames(1)}>
          <Blurb>По 36 семей на группу.</Blurb>
        </Reveal>
      </Side>
      <Desk>
        <Paper light style={{ padding: "33px 37px" }}>
          <Category light>Число семей за шесть недель</Category>
          <div
            style={{
              marginTop: 28,
              fontSize: 31,
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <span>По исходному плану</span>
            <b>240</b>
          </div>
          <div style={{ marginTop: 10 }}>
            <Meter value={240} light tone="#849c8f" />
          </div>
          <div
            style={{
              marginTop: 30,
              fontSize: 31,
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <span>По новой сверке</span>
            <b>72</b>
          </div>
          <div style={{ position: "relative", margin: "10px 0 61px" }}>
            <Meter value={240 - (240 - 72) * right} light tone={C.ink} />
            <div
              style={{
                position: "absolute",
                top: -8,
                left: (100 * 212) / 240 + "%",
                height: 34,
                width: 3,
                background: C.ink,
              }}
            />
            <div
              style={{
                position: "absolute",
                top: 31,
                right: "1.3%",
                fontFamily: M,
                fontSize: 20,
                color: C.dim,
              }}
            >
              минимум 212
            </div>
          </div>
          <div style={{ fontSize: 27, color: C.dim }}>
            12 в неделю × 6 недель = 72 семьи
          </div>
        </Paper>
        {diff ? (
          <Reveal f={gap}>
            <Paper light style={{ padding: "23px 30px", background: C.lime }}>
              <div style={{ fontSize: 47, fontWeight: 740 }}>
                212 − 72 = <Num v={140} f={gap} />
              </div>
              <span style={{ fontSize: 25 }}>
                Столько семей не хватает до минимума.
              </span>
            </Paper>
          </Reveal>
        ) : (
          <Reveal f={frames(2)} style={{ fontSize: 31, lineHeight: 1.26 }}>
            Для прежних 240 нужны 20 недель набора и ещё 7 суток наблюдения.
          </Reveal>
        )}
      </Desk>
      <Foot light>
        Записка после пересмотра · наблюдаемый поток семей, без результатов
        полевого пилота
      </Foot>
    </>
  );
}
function Decision() {
  const { f, frames } = useWordFrame(12);
  return (
    <>
      <Side
        tag="Решение руководителя"
        title={
          <>
            Запуск пилота
            <br />
            отложить
          </>
        }
      >
        <Blurb>Семьи продолжают пользоваться обычным кабинетом.</Blurb>
        <Reveal
          f={frames(3)}
          style={{ marginTop: 32, fontSize: 26, color: C.mint }}
        >
          Бюджет, трафик и уведомления ждут согласования.
        </Reveal>
      </Side>
      <Desk>
        <Paper
          style={{ padding: "28px 32px", background: C.lime, color: C.ink }}
        >
          <Category light>D-001 → D-002</Category>
          <div
            style={{
              fontSize: 48,
              fontWeight: 740,
              lineHeight: 1.13,
              marginTop: 10,
            }}
          >
            Отложить подготовку запуска
          </div>
        </Paper>
        <Reveal f={frames(1)}>
          <Paper style={{ padding: "22px 31px" }}>
            <Category>K-001 снято · новое поручение K-002</Category>
            <div
              style={{
                fontSize: 37,
                fontWeight: 700,
                lineHeight: 1.2,
                marginTop: 12,
              }}
            >
              Аналитику — сверить поток семей
            </div>
            <div style={{ fontSize: 29, color: C.mint, marginTop: 10 }}>
              До 31 марта 2027 года
            </div>
          </Paper>
        </Reveal>
        <Reveal f={frames(2)}>
          <Paper style={{ padding: "22px 31px" }}>
            <Category>Когда вернуться к запуску</Category>
            <div style={{ fontSize: 43, fontWeight: 720, marginTop: 12 }}>
              ≥ 212 семей за 6 недель
            </div>
          </Paper>
        </Reveal>
      </Desk>
      <Foot>
        family-data / out / revision.md · четыре согласования G1–G4 открыты
      </Foot>
    </>
  );
}
export const scenes = [
  Gap,
  Prompt,
  Evidence,
  Situations,
  Options,
  Product,
  Trial,
  Money,
  Output,
  Blind,
  Chat,
  Revision,
  Decision,
];
